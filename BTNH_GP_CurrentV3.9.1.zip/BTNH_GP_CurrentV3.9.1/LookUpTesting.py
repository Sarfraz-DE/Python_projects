from Main import BTN_History_Generator
from datetime import timedelta, date
import json
from sqlalchemy import create_engine
from sqlalchemy.engine.url import URL

import psycopg2

import sys

def daterange(start_date, end_date):
    for n in range(int ((end_date - start_date).days)):
        yield start_date + timedelta(n)

def RUN():
    import datetime
    
    
    a = datetime.datetime.now().replace(microsecond=0)
    start = sys.argv[1].split("-")
    end = sys.argv[2].split("-")
    
    start_date = date(int(start[-3]), int(start[-2]), int(start[-1]))   
    end_date = date(int(end[-3]), int(end[-2]), int(end[-1])) + datetime.timedelta(days = (1))

    # print(start_date)
    # print(end_date)
    # print(start)
    # print(end)
    
    obj = BTN_History_Generator()
    obj.make_connection()
    obj.set_sme_config()
    obj.set_BTN_output_table_name()
    obj.set_time_column()
    obj.set_duration()
    obj.set_lookup_output_table_name()
    obj.set_source_table_list()
    obj.set_department_split()
    obj.set_normalization_split()
    obj.set_lastcall_outComes_list()
    obj.set_Optimization_variables_list()
    obj.set_queue_list()


    for single_date in daterange(start_date, end_date):
        
        x =  ((single_date.strftime("%Y-%m-%d")))
        
        if x == str(sys.argv[2]):
                src = obj.load_data_with_threading(x,obj,True)
                result = obj.populate_btn_lookup(LastDay = True,extended = str(sys.argv[3]).lower())  
        else:
                src = obj.load_data_with_threading(x,obj,True)
                result = obj.populate_btn_lookup(LastDay = False,extended = str(sys.argv[3]).lower())  

        if result == "STOP":
            return
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            host = cfg['mysql']['host']
            port = cfg['mysql']['port']
            user = cfg['mysql']['user']
            password = cfg['mysql']['password']
            final_db  = cfg['mysql']['Finaltable'].split(".")[0].replace("","")

            db  = mysql.connector.connect(db=final_db, user=user, passwd = password, host=host, port=int(port))
            cursor = db.cursor()
            
            stmt = "delete from "+obj.final_schema+".btnh_daywise_n_calls_table as a using (select B.* from " + obj.final_schema + ".btnh_daywise_n_calls_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calldate <= '"+str(single_date)+ ") as g where a.\"BTN\"=g.\"BTN\"; " +"""  
             """ + "insert into "+obj.final_schema+".btnh_daywise_n_calls_table select B.* from " + obj.final_schema + ".btnh_daywise_n_calls_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calldate <= '"+str(single_date)+"' ;" #?       
        
            #stmt = "replace into "+obj.final_db+".btnh_daywise_n_calls_table   select * from  "+obj.final_db+".btnh_daywise_n_calls_backup  a inner join  " + obj.final_db + ".btnh_current_btns b  on a.BTN = b.BTN  where a.calldate <= '"+str(single_date)+"' ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with inserting days wise helping table")
            
            stmt = "delete from "+obj.final_schema+".btnh_future_n_calls_table as a using (select B.* from " + obj.final_schema + ".btnh_future_n_calls_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calldate <= '"+str(single_date)+ ") as g where a.\"BTN\"=g.\"BTN\"; " +"""  
             """ + "insert into "+obj.final_schema+".btnh_future_n_calls_table select B.* from " + obj.final_schema + ".btnh_future_n_calls_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calldate <= '"+str(single_date)+"' ;" #?       
        
            #stmt = "replace into  "+obj.final_db+".btnh_future_n_calls_table  select * from   "+obj.final_db+".btnh_future_n_calls_backup a inner join  " + obj.final_db + ".btnh_current_btns b  on a.BTN = b.BTN  where a.calldate <= '"+str(single_date)+"' ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with inserting future helping table")
             
            stmt = "delete from "+obj.final_schema+"."+obj.BTN_history_sme_name+" as a using (select B.* from " + obj.final_schema + ".btnh_btn_history_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.lastcalldate <= '"+str(single_date)+ ") as g where a.\"BTN\"=g.\"BTN\"; " +"""  
             """ + "insert into "+obj.final_schema+"."+obj.BTN_history_sme_name+" select B.* from " + obj.final_schema + ".btnh_btn_history_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.lastcalldate <= '"+str(single_date)+"' ;" #?       
        
            #stmt = "replace into  "+obj.final_db+"."+obj.BTN_history_sme_name+"  select * from  "+obj.final_db+".btnh_btn_history_backup a inner join  " + obj.final_db + ".btnh_current_btns b  on a.BTN = b.BTN where a.lastcalldate <= '"+str(single_date)+"' ;"
            cursor.execute(stmt)
            db.commit()
            
           # stmt = "delete from "+obj.final_schema+"."+obj.BTN_history_sme_name+" as a using (select B.* from " + obj.final_schema + ".btnh_btn_history_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.lastcalldate <= '"+str(single_date)+ ") as g where a.\"BTN\"=g.\"BTN\"; " +"""  
           #   + "insert into "+   obj.final_schema+"."+obj.BTN_history_sme_name+" select B.* from " + obj.final_schema + ".btnh_btn_history_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.lastcalldate <= '"+str(single_date)+"' ;" #?       
        
            #stmt = "replace into   "+obj.final_db+"."+obj.BTN_history_sme_name+" select * from    "+obj.final_db+".btnh_btn_history_backup a inner join  " + obj.final_db + ".btnh_current_btns b  on a.BTN = b.BTN where a.lastcalldate <= '"+str(single_date)+"' ;"
            #cursor.execute(stmt)
            #db.commit()
            print("Done with inserting btn history helping table")
            
            stmt = "delete from "+obj.final_schema+"."+obj.BTN_history_lookup_name+" as a using (select B.* from " + obj.final_schema + ".btnh_btn_lookup_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calcdate <= '"+str(single_date)+ ") as g where a.\"BTN\"=g.\"BTN\"; " +"""  
             """ + "insert into "+obj.final_schema+"."+obj.BTN_history_lookup_name+" select B.* from " + obj.final_schema + ".btnh_btn_lookup_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calcdate <= '"+str(single_date)+"' ;" #?       
                
            #stmt = "replace into  "+obj.BTN_history_lookup_name+"  select * from   "+obj.final_db+".btnh_btn_lookup_backup   a inner join  " + obj.final_db + ".btnh_current_btns b  on a.BTN = b.BTN  where a.calcdate <= '"+str(single_date)+"' ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with inserting btn lookup helping table")
            

            stmt = "delete from "+obj.final_schema+".btnh_historical_lookup as a using (select B.* from " + obj.final_schema + ".btnh_historical_lookup_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calcdate <= '"+str(single_date)+ ") as g where a.\"BTN\"=g.\"BTN\"; " +"""  
             """ + "insert into "+obj.final_schema+".btnh_historical_lookup select B.* from " + obj.final_schema + ".btnh_historical_lookup_backup as A inner join " + obj.final_schema + ".btnh_current_btns B on A.\"BTN\"=B.\"BTN\" where A.calcdate <= '"+str(single_date)+"' ;" #?       
        
            #stmt = "replace into  "+obj.final_db+".btnh_historical_lookup  select * from   "+obj.final_db+".btnh_historical_lookup_backup  a inner join  " + obj.final_db + ".btnh_current_btns b  on a.BTN = b.BTN  where a.calcdate <= '"+str(single_date)+"' ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with inserting btn historical lookup helping table")
            
            break
        
    b = datetime.datetime.now().replace(microsecond=0)
    print("\n\nTOTAL TIME TOOK: ",(b-a))



RUN()