from Main import BTN_History_Generator
from datetime import timedelta, date
import json
from sqlalchemy import create_engine
from sqlalchemy.engine.url import URL


import sys

import datetime


def daterange(start_date, end_date):
    for n in range(int ((end_date - start_date).days)):
        yield start_date + timedelta(n)

a = datetime.datetime.now().replace(microsecond=0)

start = sys.argv[1].split("-")
end = sys.argv[2].split("-")

start_date = date(int(start[-3]), int(start[-2]), int(start[-1]))   
end_date = date(int(end[-3]), int(end[-2]), int(end[-1])) + datetime.timedelta(days = (1))

obj =  BTN_History_Generator()
obj.make_connection()
obj.set_sme_config()
obj.set_BTN_output_table_name()
obj.set_time_column()
obj.set_duration()
obj.set_lookup_output_table_name()
obj.set_source_table_list()
obj.set_department_split()
obj.set_normalization_split()
obj.set_lastcall_outComes_list()
obj.set_Optimization_variables_list()

obj.set_queue_list()

for single_date in daterange(start_date, end_date):
    x =  ((single_date.strftime("%Y-%m-%d")))

    src = obj.load_data_with_threading(x,obj,False)
    result = obj.populate_btn_lookup(LastDay = True,extended = str(sys.argv[3]).lower() )  

b = datetime.datetime.now().replace(microsecond=0)
print("\n\nTOTAL TIME TOOK: ",(b-a))

