from Main import *
import datetime
import json
import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy.engine.url import URL

import logging
from threading import Thread
import psycopg2


class BTN_History_RollBack():
        
         ############################## NOT END DATE #####
    def execute_query(self,obj,query):
        with open('credentials.json', 'r') as f:
            cfg = json.load(f)

        host = cfg['mysql']['host']
        port = cfg['mysql']['port']
        user = cfg['mysql']['user']
        password = cfg['mysql']['password']
        

        db  = psycopg2.connect( host=host, port=int(port),user=user, password=password,database=cfg['mysql']['finalDatabase'].split(".")[0].replace("", ""))
        cursor = db.cursor()

        cursor.execute(query)
        db.commit()
            
        return
        ############################## NOT END DATE #####
    def Perform_RollBack(self,startDate,obj):
        """
        Perform backup and rollback if required
        """
        try:
            logging.debug('Rollback Starting')
            start = datetime.datetime.strptime(startDate, "%Y-%m-%d")
            print(start)
            print(str(start))
           #################################

            ### SETTING UP CONNECTION ###
            
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            host = cfg['mysql']['host']
            port = cfg['mysql']['port']
            user = cfg['mysql']['user']
            password = cfg['mysql']['password']
            

            db  = psycopg2.connect( host=host, port=int(port),user=user, password=password,database=cfg['mysql']['finalDatabase'].split(".")[0].replace("", ""))
            cursor = db.cursor()

            ##### DROPPING HELPING TABLES #####
            # stmt = "drop table if   exists  "+obj.final_db+".btnh_daywise_n_calls_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with Dropping days wise helping table")
            # stmt = "drop table if   exists  "+obj.final_db+".btnh_future_n_calls_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with Dropping future helping table")
            # stmt = "drop table if   exists  "+obj.final_db+".btnh_btn_history_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with Dropping btn history helping table")
            # stmt = "drop table if   exists  "+obj.final_db+".btnh_btn_lookup_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with Dropping btn lookup helping table")
            
            ##### CREATING HELPING TABLES #####
            # stmt = "create table if not exists  "+obj.final_db+".btnh_daywise_n_calls_backup as btnh_daywise_n_calls_table;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with creating days wise helping table")
            
            # stmt = "create table if not exists  "+obj.final_db+".btnh_future_n_calls_backup as btnh_future_n_calls_table;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with creating future helping table")
            
            # stmt = "create table if not exists  "+obj.final_db+".btnh_btn_history_backup as "+obj.BTN_history_sme_name+";"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with creating btn history helping table")
            
            # stmt = "create table if not exists  "+obj.final_db+".btnh_btn_lookup_backup as "+obj.BTN_history_lookup_name+";"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with creating btn lookup helping table")
            
            ###################################
            
            # print("Done with creating days wise helping table")
            # print("Done with creating future helping table")
            # print("Done with creating btn history helping table")
            # print("Done with creating btn lookup helping table")
            
           ##############################

            ##### INSERTION HELPING TABLES #####
            if obj.get_backup_table_checks() == 1:
                stmt = "create table  "+obj.final_schema+".btnh_daywise_n_calls_backup as SELECT * from "+obj.final_schema +".btnh_daywise_n_calls_table  ;"
                cursor.execute(stmt)
                db.commit()
                print("Done with creating days wise helping table")
                
                stmt = "create table  "+obj.final_schema+".btnh_future_n_calls_backup as SELECT * from  "+obj.final_schema +".btnh_future_n_calls_table ;"
                cursor.execute(stmt)
                db.commit()
                print("Done with creating future helping table")
                
                stmt = "create table    "+obj.final_schema+".btnh_btn_history_backup as SELECT * from  "+obj.final_schema+"."+obj.BTN_history_sme_name+"  ;"
                cursor.execute(stmt)
                db.commit()
                
                stmt = "create table   "+obj.final_schema+".btnh_btn_lookup_backup as SELECT * from  "+obj.final_schema +"."+obj.BTN_history_lookup_name+" ;"   
                cursor.execute(stmt)
                db.commit()
                print("Done with creating btn lookup helping table")
                
                stmt = "create table   "+obj.final_schema+".btnh_historical_lookup_backup  as SELECT * from  "+obj.final_schema+".btnh_historical_lookup ;"
                cursor.execute(stmt)
                db.commit()
                print("Done with creating btn lookup helping table")
                
                
                
                
                obj.update_backup_table_checks(2)
            ###################################
            
            
            ##### INSERTION HELPING TABLES #####
            stmt = "delete from "+obj.final_schema+".btnh_daywise_n_calls_backup as a using  "+obj.final_schema+".btnh_daywise_n_calls_table as b where a.\"BTN\"=b.\"BTN\" and b.calldate >=  '"+obj.get_previous_date()+"' ; " + "insert into "+obj.final_schema+".btnh_daywise_n_calls_backup select * from "+obj.final_schema+".btnh_daywise_n_calls_table where calldate >=  '"+obj.get_previous_date()+"' ;"            
            t1 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
            t1.start()
            
            stmt = "delete from "+obj.final_schema+".btnh_future_n_calls_backup as a using  "+obj.final_schema+".btnh_future_n_calls_table as b where a.\"BTN\"=b.\"BTN\" and b.calldate >=  '"+obj.get_previous_date()+"' ; " + "insert into "+obj.final_schema+".btnh_future_n_calls_backup select * from "+obj.final_schema+".btnh_future_n_calls_table where calldate >=  '"+obj.get_previous_date()+"' ;"            
            t2 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
            t2.start()
            
            
            stmt = "delete from "+obj.final_schema+".btnh_btn_lookup_backup as a using "+obj.final_schema+"."+obj.BTN_history_lookup_name+" as b where a.\"BTN\"=b.\"BTN\" and b.lastcalldate >=  '"+obj.get_previous_date()+"' ; " + "insert into "+obj.final_schema+".btnh_btn_lookup_backup select * from "+obj.final_schema+"."+obj.BTN_history_lookup_name+" where lastcalldate >=  '"+obj.get_previous_date()+"' ;"            
            t3 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
            t3.start()

            stmt = "delete from "+obj.final_schema+".btnh_btn_history_backup as a using "+obj.final_schema+"."+obj.BTN_history_sme_name+" as b where a.\"BTN\"=b.\"BTN\" and b.lastcalldate >=  '"+obj.get_previous_date()+"' ; " + "insert into "+obj.final_schema+".btnh_btn_history_backup select * from "+obj.final_schema+"."+obj.BTN_history_sme_name+" where lastcalldate >=  '"+obj.get_previous_date()+"' ;"            
            t4 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
            t4.start()
            t4.join()
            
            stmt = "delete from "+obj.final_schema+".btnh_btn_history_backup as a using "+obj.final_schema+"."+obj.BTN_history_sme_name+" as b where a.\"BTN\"=b.\"BTN\" and b.calcdate >=  '"+obj.get_previous_date()+"' ; " + "insert into "+obj.final_schema+".btnh_btn_history_backup select * from "+obj.final_schema+"."+obj.BTN_history_sme_name+" where calcdate >=  '"+obj.get_previous_date()+"' ;"            
            t5 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
            t5.start()
            
            stmt = "delete from "+obj.final_schema+".btnh_historical_lookup_backup as a using "+obj.final_schema+".btnh_historical_lookup as b where a.\"BTN\"=b.\"BTN\" and b.calcdate >=  '"+obj.get_previous_date()+"' ; " + "insert into "+obj.final_schema+".btnh_historical_lookup_backup select * from "+obj.final_schema+".btnh_historical_lookup where calcdate >=  '"+obj.get_previous_date()+"' ;"            
            t6 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
            t6.start()
            
            t1.join()
            t2.join()
            t3.join()
            t5.join()
            t6.join()
            
            print("Done with inserting days wise helping table")
            print("Done with inserting future helping table")            
            print("Done with inserting btn history helping table")
            print("Done with inserting btn lookup helping table")
            
            
            ##### DELETION FROM ACTUAL TABLES #####
            if obj.convert(obj.get_previous_date()) >= obj.convert((startDate.split(" "))[0]):
                stmt= "drop table if exists " + obj.final_schema + ".btnh_deleted_btns"
                cursor.execute(stmt)
                db.commit()
                
                stmt="create table " + obj.final_schema + ".btnh_deleted_btns (\"BTN\" varchar);  ALTER TABLE " + obj.final_schema + ".btnh_deleted_btns ALTER COLUMN \"BTN\" set NOT NULL, ADD PRIMARY KEY (\"BTN\");"
                cursor.execute(stmt) 
                db.commit()
                
               
                stmt="insert into " + obj.final_schema + ".btnh_deleted_btns (select \"BTN\" from "+obj.final_schema+"."+obj.BTN_history_lookup_name+"  where  lastcalldate  >= '"+startDate+"');"
                cursor.execute(stmt)
                db.commit()
                
#                stmt = "SET SQL_SAFE_UPDATES = 0;"
#                cursor.execute(stmt)
#                db.commit()
                stmt = "delete from "+obj.final_schema+".btnh_daywise_n_calls_table where calldate >= '"+startDate+"'::date  ;" 
                t1 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
                t1.start()

                stmt = "delete from  "+obj.final_schema+".btnh_future_n_calls_table where calldate >= '"+startDate+"'::date  ;"
                t2 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
                t2.start()
            
                stmt = "delete from  "+obj.final_schema+"."+obj.BTN_history_sme_name+"  where  lastcalldate  >= '"+startDate+"'::date ;"
                t3 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
                t3.start()

                stmt = "delete from  "+obj.final_schema+"."+obj.BTN_history_lookup_name+"  where  lastcalldate  >= '"+startDate+"'::date ;"
                t4 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
                t4.start()
            

                stmt = "delete from "+obj.final_schema+".btnh_historical_lookup  where  lastcalldate  >= '"+startDate+"'::date ;"
                t5 = Thread(target = self.execute_query,args = (obj,stmt,),daemon=True)
                t5.start()
            
                t1.join()
                t2.join()
                t3.join()
                t4.join()
                t5.join()
                
                stmt= "drop table if exists " + obj.final_schema + ".btnh_btn_temp_lookup"
                cursor.execute(stmt)
                db.commit()
                
                stmt="create table " + obj.final_schema + ".btnh_btn_temp_lookup (\"BTN\" varchar, calcdate date); ALTER TABLE " + obj.final_schema + ".btnh_btn_temp_lookup ALTER COLUMN \"BTN\" set NOT NULL, ALTER COLUMN calcdate set NOT NULL, ADD PRIMARY KEY(\"BTN\",calcdate); " 
                cursor.execute(stmt)
                db.commit()
               
                stmt="insert into " + obj.final_schema + ".btnh_btn_temp_lookup (select A.\"BTN\", max(A.calcdate::date) from " + obj.final_schema + ".btnh_historical_lookup as A inner join " + obj.final_schema + ".btnh_deleted_btns as B on A.\"BTN\"=B.\"BTN\" group by A.\"BTN\")"
                cursor.execute(stmt)
                db.commit()

                                
#                stmt="insert into daud.btnh_btn_temp_lookup (select btn,max(calcdate) as calcdate from daud.btnh_historical_lookup group by btn)"
#                cursor.execute(stmt)
#                db.commit()
 
                stmt = "delete from "+obj.final_schema+".btnh_btnhistory_lookup as a using (select B.* from " + obj.final_schema + ".btnh_btn_temp_lookup as A inner join " + obj.final_schema + ".btnh_historical_lookup B on A.\"BTN\"=B.\"BTN\" and A.calcdate::date=B.calcdate::date) as g where a.\"BTN\"=g.\"BTN\"; " +"""  
                """ + "insert into "+obj.final_schema+".btnh_btnhistory_lookup select B.* from " + obj.final_schema + ".btnh_btn_temp_lookup as A inner join " + obj.final_schema + ".btnh_historical_lookup B on A.\"BTN\"=B.\"BTN\" and A.calcdate::date=B.calcdate::date ;"            
                cursor.execute(stmt)
                db.commit()
                
                
                print("Done with deleting days wise   table")
                
                # stmt = "SET SQL_SAFE_UPDATES = 0;"
                # cursor.execute(stmt)
                # db.commit()
                
                print("Done with deleting future   table")
                
                # stmt = "SET SQL_SAFE_UPDATES = 0;"
                # cursor.execute(stmt)
                # db.commit()
                print("Done with deleting btn history   table")
            
                
                # stmt = "SET SQL_SAFE_UPDATES = 0;"
                # cursor.execute(stmt)
                # db.commit()
                # stmt = "replace INTO "+obj.BTN_history_lookup_name+" Select * from "+obj.final_db+"."+obj.BTN_history_sme_name+" Where calcdate > '"+startDate+"' :: date  and Lastcalldate <= '"+startDate+"' :: date ; "
                
                # cursor.execute(stmt)
                # db.commit()
                print("Done with deleting btn lookup table")
                obj.update_previous_date_checks((startDate.split(" "))[0])
                
            ###################################
            
            # stmt = "truncate table   "+obj.final_db+".btnh_daywise_n_calls_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with truncate days wise helping table")
            # stmt = "truncate table    "+obj.final_db+".btnh_future_n_calls_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with truncate future helping table")
            # stmt = "truncate table    "+obj.final_db+".btnh_btn_history_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with truncate btn history helping table")
            # stmt = "truncate table    "+obj.final_db+".btnh_btn_lookup_backup ;"
            # cursor.execute(stmt)
            # db.commit()
            # print("Done with truncate btn lookup helping table")
            

            ##### RE-POPULATING AGAIN #####
            print("re - populating btn history for "+startDate)
            # obj.load_data_with_threading(date)
            # obj.populate_btn_lookup()
            print("done re - populating btn history for "+startDate)
            db.close()
            ###################################
            logging.debug("Successfully Perform Roll Back ")
            return  
        
        # except mysql.connector.errors.ProgrammingError as e:
        #     logging.debug("No Table Created ")
        #     print("No Table Created ")
        #     return 
        
        except Exception as e:
            logging.error("ERROR IN ROLLBACK: "+str(e)) 
            ########################################
            ################ ASKED #################

            ########################################
            ##### DELETION FROM ACTUAL TABLES ######
            stmt = "delete from "+obj.final_schema+".btnh_daywise_n_calls_table where calldate >= '"+startDate+"'::date  ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with deleting days wise   table")
            
            stmt = "delete from  "+obj.final_schema+".btnh_future_n_calls_table where calldate >= '"+startDate+"'::date  ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with deleting future   table")
            
            stmt = "delete from "+obj.final_schema+"."+obj.BTN_history_sme_name+"  where  lastcalldate  >= '"+startDate+"'::date ;"
            cursor.execute(stmt)
            db.commit()
            print("Done with deleting btn history   table")
            
            stmt = "delete from "+obj.final_schema+"."+obj.BTN_history_lookup_name+"  where  lastcalldate  >= '"+startDate+"'::date ;"
            cursor.execute(stmt)
            db.commit()
            stmt = "delete from "+obj.final_schema+"."+obj.BTN_history_lookup_name+" as a using (select * from "+obj.final_schema+"."+obj.BTN_history_sme_name+" where calcdate > '"+startDate+"'::date  and Lastcalldate <= '"+startDate+"'::date) as b where a.\"BTN\"=b.\"BTN\" ; " + """ 
            """ + "insert into "+obj.final_schema+"."+obj.BTN_history_lookup_name+" as a using (select * from "+obj.final_schema+"."+obj.BTN_history_sme_name+" where calcdate > '"+startDate+"'::date  and Lastcalldate <= '"+startDate+"'::date) as b where a.\"BTN\"=b.\"BTN\" ; "
            cursor.execute(stmt)
            db.commit()
            # ###################################
            logging.exception("Exception Occur :"+str(e)+" In During re populating btn history now backing up old data")
            ##### INSERTION HELPING TABLES #####
            stmt = "insert into  "+obj.final_schema+".btnh_daywise_n_calls_table select * from "+obj.final_schema+".btnh_daywise_n_calls_backup ;"
            cursor.execute(stmt)
            db.commit()
            print("done with inserting old daywise_n_calls_backup data")
            
            stmt = "insert into "+obj.final_schema+".btnh_future_n_calls_table select * from  "+obj.final_schema+".btnh_future_n_calls_backup ;"
            cursor.execute(stmt)
            db.commit()
            print("done with inserting old future_n_calls_backup data" )
            
            stmt = "insert into  "+obj.final_schema+"."+obj.BTN_history_sme_name+" select * from "+obj.final_schema+".btnh_btn_history_backup   ;"
            cursor.execute(stmt)
            db.commit()
            print("done with inserting old btn_history_backup data"  )
            
            stmt = "delete from  "+obj.final_schema+"."+obj.BTN_history_lookup_name+" as a using  (select * from  "+obj.final_schema+".btnh_btn_lookup_backup) as b where a.\"BTN\"=b.\"BTN\" ;" + """
            """ + "insert into  "+obj.final_schema+"."+obj.BTN_history_lookup_name+" as a using  (select * from  "+obj.final_schema+".btnh_btn_lookup_backup) as b where a.\"BTN\"=b.\"BTN\" ;"
            cursor.execute(stmt)
            db.commit()
            print("done with inserting old btn_lookup_backup data")
            cursor.close()
            db.close()    
            ###################################
            