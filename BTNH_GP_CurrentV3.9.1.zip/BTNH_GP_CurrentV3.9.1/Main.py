import io
import os
import math
import json
import datetime
import hashlib
import datetime
import logging
import psycopg2
import sqlalchemy
import multiprocessing
import numpy as np
import pandas as pd
from threading import Thread
from datetime import timedelta
from sqlalchemy import create_engine
from sqlalchemy.engine.url import URL

from BTN_History_RollBack import *


logging.basicConfig(filename="process_history.log",
                    level=logging.DEBUG,
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S', )


def get_lookup_table_checks():
    """
    Get LookUp Table Checks from table_creation_flags file
    """
    df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
    return int(df.loc['lookup']['Status'])


class BTN_History_Generator():
    def get_engine_connection(self,db):
        """
        create db engine connection 
        """
        with open('credentials.json', 'r') as f:
                    cfg = json.load(f)
        host = cfg['mysql']['host']
        port = cfg['mysql']['port']
        user = cfg['mysql']['user']
        self.database = cfg['mysql']['database']
        password = cfg['mysql']['password']
        self.source_db = cfg['mysql']['SourceTable'].split(".")[0].replace("", "")
        self.config_db = cfg['mysql']['ConfigTable'].split(".")[0].replace("", "")
        self.final_schema= cfg['mysql']['Finaltable'].split(".")[0].replace("", "")
        self.role= cfg['mysql']['role'].split(".")[0].replace("", "")
        self.final_db = cfg['mysql']['finalDatabase'].split(".")[0].replace("", "")
        self.configtable = cfg['mysql']['ConfigTable']
        # print(self.configtable)
        engine = create_engine('postgresql+psycopg2://'+user+':'+password+'@'+host+':'+port+'/'+db)
        return engine.connect()

    def get_psycopg_db_cursor(self,dbe):
        """
        Create and return gp db connection
        """
        with open('credentials.json', 'r') as f:
                    cfg = json.load(f)
        host = cfg['mysql']['host']
        port = cfg['mysql']['port']
        user = cfg['mysql']['user']
        password = cfg['mysql']['password']
        db =  psycopg2.connect( host=host, port=int(port),user=user, password=password,database=dbe)
        cursor = db.cursor()
        return (db,cursor)

    def get_sme_table_checks(self):
        """
        Get SME checks from table creation flags csv file 
        """
        if os.path.isfile('table_creation_flags.csv') == False:
            df = pd.DataFrame()
            df.loc[:,'Tables'] = ['lookup', 'history', 'backup', 'previous_date']
            df.loc[:,'Status'] = ['1', '1', '1', '1000-01-01']
            df.set_index('Tables', inplace=True)
            df.to_csv('table_creation_flags.csv')
            return 0

        elif os.path.isfile('table_creation_flags.csv') == True:
            df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
            return int(df.loc['history']['Status'])

    def get_previous_date(self):
        """
        Get Previous date checks from table creation flags csv file
        """
        df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
        return str(df.loc['previous_date']['Status'])

    def update_previous_date_checks(self, status):
        """
        Update previous date checks to table creation flags csv file
        """
        if os.path.isfile('table_creation_flags.csv') == True:
            df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
            df.at['previous_date', 'Status']= str(status)
            df.to_csv('table_creation_flags.csv')

    def update_sme_table_checks(self, status):
        """
        Update SME checks to table creation flags csv file
        """
        df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
        df.at['history', 'Status']= str(status)
        df.to_csv('table_creation_flags.csv')

    def get_backup_table_checks(self):
        """
        Get backup table checks from table creation flags csv file
        """
        df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
        return int(df.loc['backup']['Status'])

    def update_lookup_table_checks(self, status):
        """
        Update lookup checks to table creation flags csv file
        """
        df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
        df.at['lookup', 'Status']= str(status)
        df.to_csv('table_creation_flags.csv')

    def update_backup_table_checks(self, status):
        """
        Update backup checks to table creation flags csv file
        """
        df = pd.read_csv('table_creation_flags.csv', index_col='Tables')
        df.at['backup', 'Status']= str(status)
        df.to_csv('table_creation_flags.csv')

    def convert(self, date_str):
        """
        Return datetime object 
        """
        format_str = '%Y-%m-%d'
        print("convert: ",date_str)
        datetime_obj = datetime.datetime.strptime(date_str,format_str)  # + datetime.timedelta(days= int(self.data_delay) * -1)
        return (datetime_obj.date())

    def get_standard_columns_sequence_for_creation(self,ncalls_arg,sme,sme_lag = False):
        """
        Get list of columns for history and lookup tables 
        """
        logging.debug("Generating BTN LookUp Table Columns")
        try:
            ##############################################
            #
            column_list=[]
            # column_list = ["BTN"]
            column_list=['calcdate']

            #### For Opt var list ####
            for i in self.lastcall_outComes_list:
                column_list.append('lastcall_'+i.lower())
                
            for i  in self.optimization_variables_list:
                column_list.append('recent_'+i.lower())
                
            column_list.append('first_calldate')
            
            column_list.append('lastdeptsplit')

            if sme == False:
                column_list.append('first_call')
            
            ######### Dept Split ##########
            ###############################
            column_list.append('lastcalldate')
            
            ########## AHT COLS ###########
            column_list.append('handletime_3_lastcall')
            column_list.append('handletime_4_lastcall')
            column_list.append('handletime_5_lastcall')
            
                
            ######### Since Cols ##########
            column_list.append('days_since_last_call')
            column_list.append('weeks_since_last_call')
            column_list.append('months_since_last_call')
            
                       
            column_list.append('days_since_first_call')
            column_list.append('weeks_since_first_call')
            column_list.append('months_since_first_call')
            
            if ncalls_arg.lower() == "n":
                column_list.append('NCalls')
                column_list.append('ncalls_24hours')
                column_list.append('ncalls_48hours')
                column_list.append('ncalls_1week')  ######################### 1 ##############
                column_list.append('ncalls_1month')
            
            elif ncalls_arg.lower() == "y":
                column_list.append('NCalls')
                column_list.append('ncalls_24hours')
                column_list.append('ncalls_48hours')
                column_list.append('ncalls_1week') ######################### 1 ##############
                column_list.append('ncalls_1month')
                
                column_list.append('ncalls_60days')
                column_list.append('ncalls_90days')
                column_list.append('ncalls_120days')
                column_list.append('ncalls_180days')
                column_list.append('ncalls_1year')

            ######### Normal OR Extended N Calls ###########
            
            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    column_list.append('first_call_'+i)
                    
                    ######### Dept Split ##########
                    ###################
                    column_list.append('lastcalldate_'+i)
    
                    column_list.append('handletime_3_'+i)
                    column_list.append('handletime_4_'+i)
                    column_list.append('handletime_5_'+i)
            
                    column_list.append('days_since_last_call_'+i)
                    column_list.append('weeks_since_last_call_'+i)
                    column_list.append('months_since_last_call_'+i)

                    if sme_lag == False:            
                        column_list.append('days_since_first_call_'+i)
                        column_list.append('weeks_since_first_call_'+i)
            
                    column_list.append('months_since_first_call_'+i)
                    
                    column_list.append('ncalls_'+i)
            
            print(column_list)    
            logging.debug("Successfully Generating BTN LookUp Table Columns For Creation")
            return column_list
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :"+str(e)+" In Generating BTN LookUp Table Columns For Creation")

    ###################################################
    def __init__(self):
        """
        Initialize BTN_History_Generator Class
        """
        with open('process_history.log', 'w'):
            pass

        logging.debug("\n\n\n")

        logging.debug("Initialization Variable In __init__ ")
        self.config_df = 0
        self.BTN_history_lookup_name = 0
        self.BTN_history_sme_name = 0
        self.n_calls_deptsplit = {}
        self.n_calls_For_All_deptsplit = {}
        self.AHT_For_All_NormalizationSplit = {}
        self.source_data_list = []
        self.all_good = True
        self.fill_queue_list = True

    def make_connection(self):
        """
        Used (username,password,host,database,port) to establish connection for source,config and btnh
        source is credentials.json
        """
        logging.debug("Making Connection")

        try:
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            host = cfg['mysql']['host']
            port = cfg['mysql']['port']
            user = cfg['mysql']['user']
            self.database = cfg['mysql']['database']
            password = cfg['mysql']['password']
            self.source_db = cfg['mysql']['SourceTable'].split(".")[0].replace("", "")
            self.config_db = cfg['mysql']['ConfigTable'].split(".")[0].replace("", "")
            self.final_schema= cfg['mysql']['Finaltable'].split(".")[0].replace("", "")
            self.role= cfg['mysql']['role'].split(".")[0].replace("", "")
            self.final_db = cfg['mysql']['finalDatabase'].split(".")[0].replace("", "")
            self.configtable = cfg['mysql']['ConfigTable']
            print(self.configtable)

            self.db, self.cursor = self.get_psycopg_db_cursor(cfg['mysql']['finalDatabase'].split(".")[0].replace("", ""))
            self.cursor = self.db.cursor()
            engine = create_engine('postgresql+psycopg2://'+user+':'+password+'@'+host+':'+port+'/'+self.final_db)
            self.src_conn = engine.connect()
            self.creation_conn = engine.connect()

            logging.debug("Successfully Made Connection ")
            engine.dispose()     
        except Exception as e:
            logging.exception("Exception Occur :" + str(e) + " In Made Connection in:")
            self.all_good = False

    def get_useful_columns(self):
        """
        Get list of columns used to generate btnh from source table/view.
        """
        logging.debug("Getting Useful Columns Function")
        try:
            useful_columns = []
            useful_columns.append("trim(btn) as \"BTN\"")
            useful_columns.append(str(self.date_col))

            for i in self.optimization_variables_list:
                useful_columns.append(i)

            for i in self.lastcall_outComes_list:
                if useful_columns.count(i) <= 0 and useful_columns.count(i.upper()) <= 0 and useful_columns.count(
                        i.lower()) <= 0:
                    useful_columns.append(i)

            if useful_columns.count("AHT") <= 0 and useful_columns.count('aht') <= 0:
                useful_columns.append("AHT")

            if useful_columns.count(self.normalization_split) <= 0 and useful_columns.count(
                    self.normalization_split.upper()) <= 0 and useful_columns.count(
                self.normalization_split.lower()) <= 0:
                useful_columns.append(self.normalization_split)

            if useful_columns.count(self.department_split) <= 0 and useful_columns.count(
                    self.department_split.upper()) <= 0 and useful_columns.count(self.department_split.lower()) <= 0:
                useful_columns.append("LOWER("+self.department_split+") AS "+self.department_split)

            useful_columns = (" , ").join(useful_columns)
            logging.debug("Successfully Get Useful Columns Function ")

            return useful_columns


        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Getting Useful Columns Function ")

    def load_source_data(self, src, fetching_date):
        """
        This function prepares a query for in loop(0-duration+1) and these queries are given to threads so that selection can be done parallel, where query is ran and appends df to datalist variable.
        Before preparing the query it first check that whether there is any btnh_filtercriteria in configdf is yes then query is prepared with that filter and if not then without, 
        following this condition there is one more condition that is whether the database name is present in src variable if yes then query directly uses src in query prep else it adds the databse name with '.' to src.
        """
        logging.debug("Loading Source Data For Table " + str(src))
        try:
            ########  Use Load Read_Sql Pandas Builtin Function For condition since it has C backend for speed ##############
            self.fetching_date = fetching_date + " 23:59:59.999"
            fetching_date = "'" + fetching_date + "'"
            #################################### Select only useful/ selected columns for BTN ###################

            ################################### Commented fot time being for testing only #######################

            threads = []
            self.source_data_list = []

            for day_difference in range(0,(self.Duration+1)):

                if type(self.config_df['btnh_filtercriteria'].values[0]) != str:
                    print(self.fetching_date)
                    print(self.fetching_date.replace(
                            "23:59:59.999", "00:00:00"))
                    if src.count(self.source_db) <= 0:
                        source_query = " SELECT " + self.get_useful_columns() + " FROM " + str(
                            self.database) + "." + str(src) + " WHERE " + str(
                            self.date_col) + "  BETWEEN      ('" + self.fetching_date.replace(
                            "23:59:59.999", "00:00:00") + "'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')  AND  ('" + self.fetching_date +"'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')  ; "
                    else:
                        source_query = " SELECT " + self.get_useful_columns() + " FROM " + str(src) +" WHERE " + str(
                            self.date_col) + "  BETWEEN     ('" + self.fetching_date.replace(
                            "23:59:59.999", "00:00:00") + "'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')  AND  ('" + self.fetching_date +"'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')   ;  "

                else:
                    if src.count(self.source_db) <= 0:
                        source_query = " SELECT " + self.get_useful_columns() + " FROM " + str(
                            self.database) + "." + str(src) + " WHERE " + str(
                            self.date_col) + "  BETWEEN    ('" + self.fetching_date.replace(
                            "23:59:59.999", "00:00:00") + "'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')  AND ('" + self.fetching_date +"'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')  " + str(self.config_df['btnh_filtercriteria'].values[0]) + " ; "
                    else:
                        source_query = " SELECT " + self.get_useful_columns() + " FROM " + str(src) + " WHERE " + str(
                            self.date_col) + "  BETWEEN     ('" + self.fetching_date.replace(
                            "23:59:59.999", "00:00:00") + "'::timestamp  -  INTERVAL '" + str(
                            day_difference) + " DAYS')  AND  ('" + self.fetching_date +"'::timestamp -  INTERVAL '" + str(
                            day_difference) + " DAYS')   " + str(self.config_df['btnh_filtercriteria'].values[0]) + " ; "

                print(source_query)
                process = Thread(target=self.select_in_parallel_using_cursor, args=(source_query,), daemon=True)

                process.start()
                threads.append(process)
                
            for process in threads:
                process.join()

            print(self.source_data_list)
            logging.debug("Successfully Loading Source Data For Table" + str(src) + " ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Loading Source Data For Table" + str(src) + " ")

    def select_in_parallel_using_cursor(self,source_query):
        """
        This function prepares a dataframe after getting result from executing the query and converts all the column names to lower case except btn
        """
        logging.debug(source_query)
        records  =pd.read_sql(sql = source_query,con=self.db,index_col="BTN")
        df = pd.DataFrame(records)
        name_dict={}
        for i in list(df.columns):
            if i != "btn":
                name_dict[i] = i.lower()

        df.rename(columns=name_dict, inplace=True)
        self.source_data_list.append(df)
        logging.debug("Completed!!!!")

    def merge_all(self):
        """
        Concatenates all the dataframes in source_Data_list and prepares one single dataframe final_source_data
        """
        print("Before")
        logging.debug("Merging All Source Table")
        try:
            self.final_source_data = pd.concat(self.source_data_list)
            if len(self.final_source_data) <= 0:
                logging.debug("0 Zero Rows In Combined Data Source")
                return

            logging.debug("Successfully Merging All Source Table ")
            print("After")
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Merging All Source Table ")

    ############################# Threading ############################
    def load_data_with_threading(self, fetching_date, obj, do_rollback):
        """
        In this function it runs a loop on source table list. Also, performs rollback if do_rollback passed as True
        It creates threads for each source table and call load_source_data and at the end after loop is finished it calls mergeall function
        """
        logging.debug("\n\n\n")
        logging.debug("Loading Source Tables With Threading")

        try:
            if do_rollback == True:
                z = BTN_History_RollBack()
                z.Perform_RollBack(fetching_date, obj)

            threads = []
            self.source_data_list = []
            for i in (self.source_table_list):
                process = Thread(target=self.load_source_data, args=(i, fetching_date,), daemon=True)
                print("Before")
                self.make_connection()
                print("After")
                process.start()
                threads.append(process)
                
            for process in threads:
                process.join()
                
            self.merge_all()
            
            logging.debug("Successfully Loading Source Tables With Threading ")
            return self.final_source_data

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Loading Source Tables With Threading ")


    def set_sme_config(self):
        """
        Querying configtable in database and preparing df and finally filtering out required client row using client name provided in json file and setting configdf
        """
        logging.debug("Setting And Loading SME Config Table")

        try:
            (db, cursor) = self.get_psycopg_db_cursor(self.final_db)
            engine = self.get_engine_connection(self.final_db)

            with open('credentials.json', 'r') as f:
                    cfg = json.load(f)
            
            client_name = cfg['mysql']['ClientName']

            config_query = "SELECT * FROM " + self.configtable + ";"
            print(config_query)
            
            self.config_df = pd.read_sql(sql=config_query,
                                         con=engine,
                                         chunksize=None)
            print(self.config_df)
            print(self.config_df.client)
            print(self.config_df.clientname)
            
            self.config_df = (self.config_df[(self.config_df.client) == str(client_name)])
            logging.debug("Successfully Setting And Loading SME Config Table ")
            print(self.config_df.client)
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Setting And Loading SME Config Table ")

    def set_BTN_output_table_name(self):
        """
        Setting btn_history table name as btnh_btn_history which can be changed.
        It can also extract (BTNHistoryTableName) from dataframe prepared in set_sme_config() and  setting local variable (BTN_history_sme_name) 
        through replacing "btnh_btn_history" with self.config_df.BTNHistoryTableName.values[0].lower().replace(" ","")
        """
        logging.debug("Getting BTN History Output Table Name From SME Config Table")

        try:
            self.BTN_history_sme_name = "btnh_btn_history"  # self.config_df.BTNHistoryTableName.values[0].lower().replace(" ","")
            logging.debug("Successfully Getting BTN History Output Table Name From SME Config Table ")

        except Exception as e:

            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting BTN History Output Table Name From SME Config Table ")

    def set_lookup_output_table_name(self):
        """
        Setting btn_history lookup table name as btnh_btnhistory_lookup which can be changed.
        It can also extract (BTNHistory_LookupTable) from dataframe prepared in set_sme_config() and  setting local variable (BTN_history_lookup_name) 
        through replacing "btnh_btnhistory_lookup" with self.config_df["BTNHistory_LookupTable"].values[0].lower().replace(" ","")
        """
        logging.debug("Getting BTN History LookUp Table Name From SME Config Table")

        try:
            self.BTN_history_lookup_name = "btnh_btnhistory_lookup"  # self.config_df["BTNHistory_LookupTable"].values[0].lower().replace(" ","")
            logging.debug("Successfully Getting BTN History LookUp Table Name From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting BTN History LookUp Table Name From SME Config Table ")

    def set_time_column(self):
        """
        Extracting (VACA_Date_Filter_Column) from dataframe prepared in set_sme_config() and  setting local variable (date_col) 
        """
        logging.debug("Getting Time Columns Value (CallTime) From SME Config Table")

        try:
            self.date_col = self.config_df.vaca_date_filter_column.values[0].lower().replace("", "").replace(" ", "")
            logging.debug("Successfully Getting Time Columns Value (CallTime) From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting Time Columns Value (CallTime) From SME Config Table ")

    def set_duration(self):
        """
        Extracting (Duration) from dataframe prepared in set_sme_config() and  setting local variable (Duration) 
        and setting local variable(data_delay)=0 (as currently data_Delay is not used)
        """

        logging.debug("Getting Duration Columns Value From SME Config Table")

        try:
            self.Duration = self.config_df.duration.values[0]
            self.data_delay = 0  # self.config_df.DataDelay.values[0]

            logging.debug("Successfully Getting Duration Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting Duration Columns Value From SME Config Table ")

    def set_source_table_list(self):
        """
        Extracting (BTNH_SOURCETABLE) list from dataframe prepared in set_sme_config() and  setting local variable (source_table_list) list.
        Used list because you may have multiple source tables
        """

        logging.debug("Getting Duration Columns Value From SME Config Table")

        try:
            self.source_table_list = self.config_df.btnh_sourcetable.values[0].lower().replace(" ", "").replace(" ",
                                                                                                                "").split(
                ",")
            logging.debug("Successfully Getting Duration Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting Duration Columns Value From SME Config Table ")

    def set_department_split(self):
        """
        Extracting (BTNH_Department_Split) from dataframe prepared in set_sme_config() and  setting local variable (department_split) 
        """
        logging.debug("Getting DepartmentSplit Columns Value From SME Config Table")

        try:
            self.department_split = self.config_df.btnh_department_split.values[0].lower().replace(" ", "").replace("",
                                                                                                                    "")

            logging.debug("Successfully Getting DepartmentSplit Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting DepartmentSplit Columns Value From SME Config Table ")

    def set_normalization_split(self):
        """
        Extracting (BTNH_Normalized_Split) from dataframe prepared in set_sme_config() and  setting local variable (normalization_split) 
        """

        logging.debug("Getting NormalizationSplit Columns Value From SME Config Table")

        try:

            self.normalization_split = self.config_df.btnh_normalized_split.values[0].lower().replace(" ", "").replace(
                "", "")
            logging.debug("Successfully Getting NormalizationSplit Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Getting NormalizationSplit Columns Value From SME Config Table ")

    def set_lastcall_outComes_list(self):
        """
        Extracting (BTNH_LastCall_Outcome) list from dataframe prepared in set_sme_config() and  setting local variable (LastCall_outComes_list) list.
        Used list because you may have multiple outcomes.
        """

        logging.debug("Getting LastCall outComes list Columns Value From SME Config Table")

        try:
            self.lastcall_outComes_list = self.config_df.btnh_lastcall_outcome.values[0].lower().replace("",
                                                                                                         "").replace(
                " ", "").split(',')

            logging.debug("Successfully Getting LastCall outComes list Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(
                e) + " In Getting LastCall outComes list Columns Value From SME Config Table ")

    def set_Optimization_variables_list(self):
        """
        Extracting (BTNH_Opt_Variables) list from dataframe prepared in set_sme_config() and  setting local variable optimization_variables_list) list.
        Used list because you may have multiple optimization variables.
        """
        logging.debug("Getting Optimization Variables list Columns Value From SME Config Table")

        try:
            self.optimization_variables_list = self.config_df.btnh_opt_variables.values[0].lower().replace("",
                                                                                                           "").replace(
                " ", "").split(",")

            logging.debug("Successfully Getting Optimization Variables list Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(
                e) + " In Getting Optimization Variables list Columns Value From SME Config Table ")

    def set_queue_list(self):
        """
        Extracting (Program_ID) list from json file and  setting local variable (queue_list) list. Used list because you may have multiple Queues.
        """
        logging.debug("Getting Queue list Columns Value From SME Config Table")

        try:
            ####################################### 
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            programID = cfg['mysql']['programID']

            self.queue_list = programID.lower().replace("", "").replace(" ", "").split(",")
            

            logging.debug("Successfully Getting Queue list Columns Value From SME Config Table ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Getting Queue list Columns Value From SME Config Table ")
            
    def get_standard_columns_sequence(self,ncalls_arg,sme = False,sme_lag = False):
        """
        Get list of standarad columns sequence for lookup and history table
        """
         
        logging.debug("Generating BTN LookUp Table Columns")
        
        try:
            ##############################################
            column_list = ['\"BTN\"']
            column_list.append('calcdate')

            #### For Opt var list ####
            for i in self.lastcall_outComes_list:
                column_list.append("lastcall_"+i.lower())
                
            for i  in self.optimization_variables_list:
                column_list.append("recent_"+i.lower())
                
            column_list.append("first_calldate")
            
            column_list.append("lastdeptsplit")

            if sme == False:
                column_list.append("first_call")
            
            ######### Dept Split ##########
            ###############################
            column_list.append("lastcalldate")
            
            ########## AHT COLS ###########
            column_list.append("handletime_3_lastcall")
            column_list.append("handletime_4_lastcall")
            column_list.append("handletime_5_lastcall")
            
                
            ######### Since Cols ##########
            column_list.append("days_since_last_call")
            column_list.append("weeks_since_last_call")
            column_list.append("months_since_last_call")
            
            if sme_lag == False:            
                column_list.append("days_since_first_call")
                column_list.append("weeks_since_first_call")
            column_list.append("months_since_first_call")
            
            if ncalls_arg.lower() == "n":
                column_list.append('\"NCalls\"')
                column_list.append("ncalls_24hours")
                column_list.append("ncalls_48hours")
                column_list.append("ncalls_1week")  ######################### 1 ##############
                column_list.append("ncalls_1month")
            
            elif ncalls_arg.lower() == "y":
                column_list.append('\"NCalls\"')
                column_list.append("ncalls_24hours")
                column_list.append("ncalls_48hours")
                column_list.append("ncalls_1week") ######################### 1 ##############
                column_list.append("ncalls_1month")
                
                column_list.append("ncalls_60days")
                column_list.append("ncalls_90days")
                column_list.append("ncalls_120days")
                column_list.append("ncalls_180days")
                column_list.append("ncalls_1year")
                
            ######### Normal OR Extended N Calls ###########
            
            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    column_list.append("first_call_"+i)
                    
                    ######### Dept Split ##########
                    ###################
                    column_list.append("lastcalldate_"+i)
    
                    column_list.append("handletime_3_"+i)
                    column_list.append("handletime_4_"+i)
                    column_list.append("handletime_5_"+i)
            
                    column_list.append("days_since_last_call_"+i)
                    column_list.append("weeks_since_last_call_"+i)
                    column_list.append("months_since_last_call_"+i)

                    if sme_lag == False:            
                        column_list.append("days_since_first_call_"+i)
                        column_list.append("weeks_since_first_call_"+i)
            
                    column_list.append("months_since_first_call_"+i)
                    
                    column_list.append('ncalls_'+i)
            
            
                
            logging.debug("Successfully Generating BTN LookUp Table Columns ")
            return (" , ").join(column_list)
            
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :"+str(e)+" In Generating BTN LookUp Table Columns ")
            
    def get_standard_columns_sequence_for_stagging(self,ncalls_arg,sme,sme_lag = False):
        """
        Get list of standard columns sequence for lookup staging table and history staging table 
        """
        logging.debug("Generating BTN LookUp Table Columns")
        
        try:
            ##############################################
            column_list = ['\"BTN\"']
            column_list.append('calcdate')

            #### For Opt var list ####
            for i in self.lastcall_outComes_list:
                column_list.append("lastcall_"+i.lower())
                
            for i  in self.optimization_variables_list:
                column_list.append("recent_"+i.lower())
                
            column_list.append("first_calldate")
            
            column_list.append("lastdeptsplit")

            if sme == False:
                column_list.append("first_call")
            
            ######### Dept Split ##########
            ###############################
            column_list.append("lastcalldate")
            
            ########## AHT COLS ###########
            column_list.append("handletime_3_lastcall")
            column_list.append("handletime_4_lastcall")
            column_list.append("handletime_5_lastcall")
            
                
            ######### Since Cols ##########
            column_list.append("days_since_last_call")
            column_list.append("weeks_since_last_call")
            column_list.append("months_since_last_call")
            
            if sme_lag == False:            
                column_list.append("days_since_first_call")
                column_list.append("weeks_since_first_call")
            column_list.append("months_since_first_call")
            
            if ncalls_arg.lower() == "n":
                column_list.append('\"NCalls\"')
                column_list.append("ncalls_24hours")
                column_list.append("ncalls_48hours")
                column_list.append("ncalls_1week")  ######################### 1 ##############
                column_list.append("ncalls_1month")
            
            elif ncalls_arg.lower() == "y":
                column_list.append('\"NCalls\"')
                column_list.append("ncalls_24hours")
                column_list.append("ncalls_48hours")
                column_list.append("ncalls_1week") ######################### 1 ##############
                column_list.append("ncalls_1month")
                
                column_list.append("ncalls_60days")
                column_list.append("ncalls_90days")
                column_list.append("ncalls_120days")
                column_list.append("ncalls_180days")
                column_list.append("ncalls_1year")
                
            ######### Normal OR Extended N Calls ###########
            
            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    column_list.append("first_call_"+i)
                    
                    ######### Dept Split ##########
                    ###################
                    column_list.append("lastcalldate_"+i+"::date")
    
                    column_list.append("handletime_3_"+i)
                    column_list.append("handletime_4_"+i)
                    column_list.append("handletime_5_"+i)
            
                    column_list.append("days_since_last_call_"+i)
                    column_list.append("weeks_since_last_call_"+i)
                    column_list.append("months_since_last_call_"+i)

                    if sme_lag == False:            
                        column_list.append("days_since_first_call_"+i)
                        column_list.append("weeks_since_first_call_"+i)
            
                    column_list.append("months_since_first_call_"+i)
                    
                    column_list.append('ncalls_'+i)            
                
            logging.debug("Successfully Generating BTN LookUp Table Columns ")
            return (" , ").join(column_list)
            
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :"+str(e)+" In Generating BTN LookUp Table Columns ")

    def get_standard_columns_datatype_for_creation(self,ncalls_arg,sme,stagging,sme_lag = False):
        """
        Get list of columns with their datatypes for tables creation. E.g., history and lookup tables.
        """
        logging.debug("Generating BTN LookUp Table Columns")
        
        try:
            ##############################################
            column_list = ['\"BTN\"'+" VARCHAR(65)"]
            column_list.append('calcdate' + " date")

            #### For Opt var list ####
            for i in self.lastcall_outComes_list:
                column_list.append("lastcall_"+i.lower()+" VARCHAR(255)")
                
            for i  in self.optimization_variables_list:
                column_list.append("recent_"+i.lower()+" VARCHAR(15)")
                
            column_list.append("first_calldate"+ " date")
            
            column_list.append("lastdeptsplit"+ " VARCHAR(20)")

            if sme == False:
                column_list.append("first_call"+ " VARCHAR(5)")
            
            ######### Dept Split ##########
            ###############################
            
            column_list.append("lastcalldate" +" date")
            
            ########## AHT COLS ###########
            column_list.append("handletime_3_lastcall"+" VARCHAR(15)")
            column_list.append("handletime_4_lastcall"+" VARCHAR(15)")
            column_list.append("handletime_5_lastcall"+" VARCHAR(15)")
            
                
            ######### Since Cols ##########
            column_list.append("days_since_last_call"+" VARCHAR(15)")
            column_list.append("weeks_since_last_call"+" VARCHAR(15)")
            column_list.append("months_since_last_call"+" VARCHAR(15)")
            
            if sme_lag == False:            
                column_list.append("days_since_first_call"+" VARCHAR(15)")
                column_list.append("weeks_since_first_call"+" VARCHAR(15)")
            column_list.append("months_since_first_call"+" VARCHAR(15)")
            
            if ncalls_arg.lower() == "n":
                column_list.append('\"NCalls\"' +" VARCHAR(15)")
                column_list.append("ncalls_24hours" +" VARCHAR(15)")
                column_list.append("ncalls_48hours"+" VARCHAR(15)")
                column_list.append("ncalls_1week"+" VARCHAR(15)")  ######################### 1 ##############
                column_list.append("ncalls_1month"+" VARCHAR(15)")
            
            elif ncalls_arg.lower() == "y":
                column_list.append('\"NCalls\"'+" VARCHAR(15)")
                column_list.append("ncalls_24hours"+" VARCHAR(15)")
                column_list.append("ncalls_48hours"+" VARCHAR(15)")
                column_list.append("ncalls_1week"+" VARCHAR(15)") ######################### 1 ##############
                column_list.append("ncalls_1month"+" VARCHAR(15)")
                
                column_list.append("ncalls_60days"+" VARCHAR(15)")
                column_list.append("ncalls_90days"+" VARCHAR(15)")
                column_list.append("ncalls_120days"+" VARCHAR(15)")
                column_list.append("ncalls_180days"+" VARCHAR(15)")
                column_list.append("ncalls_1year"+" VARCHAR(15)")            
                
            ######### Normal OR Extended N Calls ###########
            
            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    column_list.append("first_call_"+i+" VARCHAR(5)")
                    
                    ######### Dept Split ##########
                    ###################
                    if stagging==True:
                        column_list.append("lastcalldate_"+i+" VARCHAR(15)")
                    else:    
                        column_list.append("lastcalldate_"+i+" date")
                        
                    column_list.append("handletime_3_"+i+" VARCHAR(15)")
                    column_list.append("handletime_4_"+i+" VARCHAR(15)")
                    column_list.append("handletime_5_"+i+" VARCHAR(15)")
            
                    column_list.append("days_since_last_call_"+i+" VARCHAR(15)")
                    column_list.append("weeks_since_last_call_"+i+" VARCHAR(15)")
                    column_list.append("months_since_last_call_"+i+" VARCHAR(15)")

                    if sme_lag == False:            
                        column_list.append("days_since_first_call_"+i+" VARCHAR(15)")
                        column_list.append("weeks_since_first_call_"+i+" VARCHAR(15)")
            
                    column_list.append("months_since_first_call_"+i+" VARCHAR(15)")
                    
                    column_list.append('ncalls_'+i+" VARCHAR(15)")
                
            logging.debug("Successfully Generating BTN Table creation Columns ")
            return (" , ").join(column_list)
            
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :"+str(e)+" In Generating BTN LookUp Table Columns ")

    def compute_lastCalls_variables(self):
        """
        Compute lastcall variables from lastcall_outcomes_list. 
        These are the steps: 
        1) creating temp_df using frame dataframe and extracting data of lastcall_outcomes_list from it.
        2) adding one column call duration in temp_df and assigning the values to it through frame dataframe(date.col i.e callTime).
        3) adding column for last_dept_split and assigning values using frame dataframe(dept_split)
        4) assigning ranks to temp_df on the basis of callduration.
        5) selecting rank=1 rows as we need to have lastcall information.
        6) appending lastcall_ to every column name.
        7) deleting lastcall_duration and lastcall_Rank from temp_df
        8) assigning temp_df to lastCall_var_df
        """

        logging.debug("Computing LastCall Variables")

        try:
            temp_df = self.frame[self.lastcall_outComes_list]
            temp_df.loc[:,'call_duration'] = self.frame[self.date_col]
            temp_df.loc[:,'lastdeptsplit'] = self.frame[self.department_split]
            temp_df.loc[:, 'rank'] = temp_df.groupby("BTN")['call_duration'].rank(method='first', ascending=False)
            temp_df = temp_df[temp_df['rank'] == 1]

            temp_df.rename(columns=dict(zip(temp_df.columns, ["lastcall_" + x.lower() for x in temp_df.columns])),
                           inplace=True)

            try:
                del temp_df['lastcall_call_duration']
            except Exception as identifier:
                pass

            del temp_df['lastcall_rank']

            self.lastcall_var_df = temp_df.fillna('NA')
            print()
            print()
            print()

            print("LastCall Var Head: ", temp_df.columns)
            print()

            print()
            print()
            print()

            logging.debug("Successfully Computing LastCall Variables ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Computing LastCall Variables ")

    def compute_optimization_variables(self):
        """
        Calculate recent_* variables using optimization variables list. 
        1) creating temp_df using final_source_data dataframe and extracting data of optimization_variables_list.
        2) adding colum callDuration in temp_df and assigning values to it through final_source_data dataframe(data.col)
        3) converting temp_df(optimization_Variables_list) to numeric type
        4) performing groupby operation on temp_df using btn and applying aggregate function on groupby by passing sum function.
        5) merging temp_df with frame[date.col] on the basis on btn and method is inner. So that we get only those rows which are of current fetch date.
        6) assigning ranks to temp_df on the basis of callduration.
        7) selecting rank=1 rows as we need to have lastcall information.(why?)
        8) preparing dictionary with key as column name and value as lambda expression, lambda expression checks the value of optimization variable if its >=1 then it assign 1 to it else 0.
        if by chance any of the optimization variable is string it will throw an error as converting string to numeric is not possible (tried with skill variable)
        """
        logging.debug("Computing Optimization Variables")
        try:
            temp_df = self.final_source_data[(self.optimization_variables_list)]
            temp_df.loc[:,'call_duration'] = self.final_source_data[self.date_col]
            temp_df = temp_df[(self.optimization_variables_list)].apply(pd.to_numeric)
            
            temp_df = temp_df.groupby("BTN").agg(sum)

            # f=self.frame[self.date_col].to_frame()
            # f.to_csv('opt.csv')
            temp_df = pd.merge(temp_df, self.frame[self.date_col].to_frame(), on='BTN', how='inner')
            temp_df.loc[:,'rank'] = temp_df.groupby("BTN")[self.date_col].rank(method='first', ascending=False)
            temp_df = temp_df[temp_df['rank'] == 1]
            # temp_df.to_csv('opt_check.csv')
            temp_df = temp_df.groupby("BTN").agg(lambda x: 1 if x.values[0] >= 1 else 0 )
            cols = {i:"recent_" + i.lower() for i in self.optimization_variables_list}
            temp_df.rename(columns=cols,inplace=True)
            self.recent_opt_var_df = temp_df.fillna('NA')
#            self.recent_opt_var_df.to_csv('recent_opt_var.csv')
            print()
            print()
            print()
            print("Opt Var Head: ", temp_df.columns)
            print()
            print()
            print()
            print()
            logging.debug("Successfully Computing Optimization Variables ")
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Computing Optimization Variables ")

    def compute_normalimzationSplit_variables(self):
        """ Calculate bucketed handletime_* variables using these steps:
        1) prepares dataframe (temp_df) from frame by selecting(date_col,normalization_split,dept_split and aht).
        2) assign ranks in temp_Df by grouping by btn and dept_split on the basis of date_col
        3) assigning subranks in temp_df by grouping by btn on the basis of date_col
        4) selecting rank==1 data for temp_Df
        5) introducing new column to temp_df i.e deptsplit_vdn prepared by concatenating deptsplit and normalization split
        6) introducing aht_rank column by computing grouping temp_df on deptsplit_vdn and assigning ranks to aht.
        7) introducing new column i.e vdn_count by grouping temp_df by deptsplit_vdn and counting btn corresponding to it.
        8) after preparing temp_df populating_NormalizationSplit_columns_with_origin_logic() is called 
        """
        logging.debug("Computing AHT Variables")
        try:
            temp_df = self.frame[[self.date_col, self.normalization_split, 'aht', self.department_split]]
            temp_df.loc[:, 'rank'] = temp_df.groupby(["BTN", self.department_split])[self.date_col].rank(method='first',
                                                                                                         ascending=False)
            temp_df.loc[:, 'sub_rank'] = temp_df.groupby(["BTN"])[self.date_col].rank(method='first', ascending=False)

            temp_df = temp_df[temp_df['rank'] == 1]

            temp_df['deptsplit_vdn'] = temp_df[self.department_split].astype(str) + "_" + temp_df[
                self.normalization_split].astype(str)
            temp_df.reset_index(level=0, inplace=True)
            temp_df.set_index('deptsplit_vdn', inplace=True)

            temp_df['aht'] = temp_df['aht'].apply(pd.np.float64)
            temp_df = temp_df.sort_values(by=['deptsplit_vdn', 'aht'])

            temp_df.loc[:,'aht_rank'] = temp_df.groupby('deptsplit_vdn')['aht'].rank(method='dense', ascending=True)
            temp_df.loc[:,'vdn_count'] = temp_df.groupby('deptsplit_vdn')['BTN'].count()

            ##### vdn[aht] #####
            threads = []
            t = Thread(target=self.populating_NormalizationSplit_columns_with_origin_logic, args=("NONE", temp_df,),
                       daemon=True)
            t.start()
            threads.append(t)

            if len(self.queue_list) > 1:

                for i in self.queue_list:
                    t = Thread(target=self.populating_NormalizationSplit_columns_with_origin_logic, args=(i, temp_df,),
                               daemon=True)
                    t.start()
                    threads.append(t)

            for process in threads:
                process.join()

            logging.debug("Successfully Computing AHT Variables ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Computing AHT Variables ")

    def populating_NormalizationSplit_columns_with_origin_logic(self, deptsplit, temp_df):
        """
        1) if conditions to check what is the value of deptsplit if it's none then temp_df is prepared by selecting subrank==1 data.
        2) else if there is a value then it selects the data corresponding to that deptsplit value.
        3) if none it prepares handle time with lastcall appended buckets with a specified formula you can see that in code. 
        4) else it prepares handletime buckets with deptsplit appended to it.
        """
        logging.debug("Populating AHT Variables with_origin_logic programID: " + str(deptsplit))
        try:
            if deptsplit == "NONE":
                temp_df = temp_df[temp_df['sub_rank'] == 1]
            elif deptsplit != "NONE":
                temp_df = temp_df[temp_df[str(self.department_split)] == str(deptsplit)]
            if deptsplit == "NONE":
                temp_df.loc[:,'handletime_3_lastcall'] = (3 * temp_df['aht_rank'] / temp_df['vdn_count'] - 0.500001).apply(
                    lambda x: round(x) if pd.isna(x) == False else x)
                temp_df.loc[:,'handletime_4_lastcall'] = (4 * temp_df['aht_rank'] / temp_df['vdn_count'] - 0.500001).apply(
                    lambda x: round(x) if pd.isna(x) == False else x)
                temp_df.loc[:,'handletime_5_lastcall'] = (5 * temp_df['aht_rank'] / temp_df['vdn_count'] - 0.500001).apply(
                    lambda x: round(x) if pd.isna(x) == False else x)
            else:
                temp_df.loc[:,"handletime_3_" + deptsplit] = (
                        3 * temp_df['aht_rank'] / temp_df['vdn_count'] - 0.500001).apply(
                    lambda x: round(x) if pd.isna(x) == False else x)
                temp_df.loc[:,"handletime_4_" + deptsplit] = (
                        4 * temp_df['aht_rank'] / temp_df['vdn_count'] - 0.500001).apply(
                    lambda x: round(x) if pd.isna(x) == False else x)
                temp_df.loc[:,"handletime_5_" + deptsplit] = (
                        5 * temp_df['aht_rank'] / temp_df['vdn_count'] - 0.500001).apply(
                    lambda x: round(x) if pd.isna(x) == False else x)

            temp_df.reset_index(level=0, inplace=True)
            temp_df.set_index("BTN", inplace=True)

            del temp_df['deptsplit_vdn']
            del temp_df['sub_rank']
            del temp_df['rank']

            del temp_df[self.normalization_split]
            del temp_df['aht']
            del temp_df[self.date_col]
            del temp_df['aht_rank']
            del temp_df['vdn_count']
            del temp_df[self.department_split]
            print()
            print()
            print()

            print("Norm Var Head: ", temp_df.columns)
            print()

            print()
            print()
            print()

            temp_df = temp_df.fillna("NA")
            self.AHT_For_All_NormalizationSplit[deptsplit] = temp_df

            logging.debug("Successfully Populating AHT Variables with_origin_logic ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Populating AHT Variables with_origin_logic ")

    ############################################################

    def prepare_previous_NCalls(self, extended):
        """
        If lastday flag is true then this function gets called.
        This function prepares a query, query is basically a create statement which creates table(btnh_previous_Ncalls) for each day using another table in database
        i.e (btnh.daywise_n_calls_table) and compute some ncalls variables from that table on the basis of extended value.
        (like for extended = N then Ncall variables would be Ncalls_24hours,Ncalls_48hours,Ncalls_1week,Ncalls_1month
        """
        logging.debug("prepare_previous_NCalls")
        try:
            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            db_name = "" + self.final_schema + ".btnh_daywise_n_calls_table"
            (db,cursor) = self.get_psycopg_db_cursor(self.final_db)

            if os.path.isfile('table_creation_flags.csv') == True and get_lookup_table_checks() == 2:

                stmt = "drop table if exists " + self.final_schema + ".btnh_previous_NCalls"
                print(stmt)
                cursor.execute(stmt)
                db.commit()        

                if extended.lower() == "y":

                    query = """create   table """ + self.final_schema + """.btnh_previous_NCalls AS select a.\"BTN\"  AS \"BTN\",
                                COALESCE(sum(case when a.calldate >=          """ + passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                                COALESCE(sum(case when a.calldate >= (""" + passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date - interval '60 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_60days,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '90 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_90days,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '120 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_120days,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '180 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_180days,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '360 days' )  + interval '1 days') then a.\"NCalls\" end),0) ncalls_1year 
                                
                                from """ + db_name + """ a
                                
                                group by a.\"BTN\" DISTRIBUTED BY (\"BTN\");""".replace("\n", ' ')

                else:
                    query = """create   table """ + self.final_schema + """.btnh_previous_NCalls  AS select a.\"BTN\"  as \"BTN\",
                                COALESCE(sum(case when a.calldate >=          """ + passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                                COALESCE(sum(case when a.calldate >= (""" + passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                                COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month                            
                                from """ + db_name + """ a

                                group by a.\"BTN\" DISTRIBUTED BY (\"BTN\");""".replace("\n", ' ')

                print(query)
                cursor.execute(query)
                result = db.commit()

                pk_query = "ALTER TABLE  " + self.final_schema + ".btnh_previous_NCalls  ALTER COLUMN \"BTN\" set NOT NULL, ADD PRIMARY KEY (\"BTN\");"
                print(pk_query)
                cursor.execute(pk_query)
                db.commit()
                print("DONE WITH Insertion PK")
                cursor.close()
                db.close()
            # creation_conn.close()

            logging.debug("Successfully prepare_previous_NCalls")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " prepare_previous_NCalls ")

    def fill_current_btns(self):
        """
        Creates the table in database for distinct btns 
        1) prepare data fram by performing groupby operation on the dataframe using btns so that there is one row of each btn on that date.
        2) dump the dataframe into the database table(btnh_current_btns)
        """
        logging.debug("Inserting Current BTNS")

        try:
            (db, cursor) = self.get_psycopg_db_cursor(self.final_db)

            temp_df = self.frame[['calldate', self.department_split]]
            temp_df = ((temp_df[["calldate"]].groupby("BTN")).first())

            current_btnss=self.get_engine_connection(self.final_db)
            #temp_df.reset_index()
            pk_query="Drop table if  exists "+self.final_schema+".btnh_current_btns;"
            cursor.execute(pk_query)
            db.commit()
            
            pk_query="create table "+self.final_schema+".btnh_current_btns"+"(\"BTN\" VARCHAR(65),calldate date) DISTRIBUTED BY (\"BTN\"); GRANT ALL PRIVILEGES ON " + self.final_schema+".btnh_current_btns TO " + self.role + "; "
            cursor.execute(pk_query)
            db.commit()
            
            csv_io = io.StringIO()
            temp_df.to_csv(csv_io, sep='\t', header=False, index=True)
            csv_io.seek(0)

            cursor.copy_expert("copy "+self.final_schema + ".btnh_current_btns from stdin with csv delimiter '\t'",csv_io)
            db.commit()

            
            pk_query = "ALTER TABLE  " + self.final_schema + ".btnh_current_btns  ADD PRIMARY KEY (\"BTN\")"
            print(pk_query)
            cursor.execute(pk_query)
            db.commit()
            print("DONE WITH Insertion PK")

            current_btnss.close()
            cursor.close()
            db.close()
            

            logging.debug("Successfully Inserting Current BTNS ")

        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Inserting Current BTNS ")

    def run_n_calls(self):
        """
        1) first it calls n_calls() for deptsplit=NONE and then for each queue
        """

        logging.debug("Running N Calls Computation In Threading")

        try:

            threads = []
            t = Thread(target=self.n_calls, args=("NONE", True,), daemon=True)
            t.start()
            t.join()

            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    t = Thread(target=self.n_calls, args=(i, False,), daemon=True)

                    t.start()
                    threads.append(t)

                for process in threads:
                    process.join()

            logging.debug("Successfully Running N Calls Computation In Threading ")

        except Exception as e:

            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Running N Calls Computation In Threading ")

    def n_calls(self, programID, write):
        """
        This function basically creates table in our database i.e btnh_future_n_calls_table and this table has count of ncalls deptwise. i.e how many calls are there of a particular btn in this dept. 
        It also prepares n_calls_deptSplit dict program_id as key which is later used in populating btn lookup.
        if programid received by function is null then cumulative ncalls are prepared with first_calldate column where as if its not null
        then deptwise ncalls are prepared per btn  and lastcalldate on deprwise is added in columns 
        """

        logging.debug("Computing N Calls For ProgramID: " + str(programID))

        try:

            temp_df = self.frame[['calldate', self.department_split]]

            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            logging.debug("PASSED DATE: " + str(passedDate))
            if write == True:
                n_calls_creation_conn =  self.get_engine_connection(self.final_db)

                temp_df = (temp_df.groupby(["BTN", self.department_split])[
                               'calldate'].count()).to_frame()  # .add( ncalls_df['NCalls'] , fill_value  = 0)

                temp_df.reset_index(level=0, inplace=True)
                temp_df.reset_index(level=0, inplace=True)
                temp_df.set_index("BTN", inplace=True)

                temp_df.rename(columns={self.department_split: "deptsplit", "calldate": "NCalls"}, inplace=True)
                temp_df.loc[:,'calldate'] = str(self.fetching_date.split(" ")[0])
                (db, cursor) = self.get_psycopg_db_cursor(self.final_db)
                if os.path.isfile('table_creation_flags.csv') == False or get_lookup_table_checks() == 1:
                    
                    pk_query="CREATE TABLE "+self.final_schema +".btnh_future_n_calls_table(\"BTN\" VARCHAR(65),deptsplit VARCHAR(20),\"NCalls\" INT,calldate date) DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calldate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """
                    GRANT ALL PRIVILEGES ON """ + self.final_schema+".btnh_future_n_calls_table TO " + self.role + "; "
                    print(pk_query)
                    cursor.execute(pk_query)
                    db.commit()
                    pk_query = "ALTER TABLE   "+self.final_schema +".btnh_future_n_calls_table ALTER COLUMN \"BTN\" set not NULL , ADD PRIMARY KEY (\"BTN\",\"deptsplit\",\"calldate\");"
                    print(pk_query)
                    cursor.execute(pk_query)
                    db.commit()
                    
                    print("DONE WITH PK")
                
                csv_io = io.StringIO()
                temp_df.to_csv(csv_io, sep='\t', header=False, index=True)
                csv_io.seek(0)

                cursor.copy_expert("copy "+self.final_schema + ".btnh_future_n_calls_table from stdin with csv delimiter '\t'",csv_io)
                db.commit()
                db_name =self.final_schema + ".btnh_future_n_calls_table"
                sum_statement = "COALESCE (Cast(Sum(a.\"NCalls\") as INTEGER),0)"

                try:
                    query = "Select b.\"BTN\" , " + sum_statement + " as \"NCalls\", a.deptsplit as deptsplit, COALESCE(min(a.calldate), (" + passedDate + " ::date ) )  as first_calldate, max(a.calldate) as lastcalldate from " + db_name + " a right join   " + self.final_schema + ".btnh_current_btns b on a.\"BTN\" = b.\"BTN\" group  by b.\"BTN\", a.deptsplit;"
                    print("\nQUERY :", query)
                    print()

                    ############ Getting Data From The Table #####################
                    A_ncalls_df = (
                        pd.read_sql(
                            sql=query,
                            con=self.db,
                            chunksize=None,
                            index_col="BTN")
                    )

                    ncalls_df = A_ncalls_df.groupby("BTN").agg({"NCalls": sum, "first_calldate": min})
                    self.n_calls_frame = A_ncalls_df
                    n_calls_creation_conn.close()
                    cursor.close()
                    db.commit()
                    db.close()
                except Exception as e:
                    self.all_good = False
                    logging.exception(
                        "Exception Occur :" + str(e) + " In Computing N Calls For ProgramID: " + str(programID) + " ")

                ##############################################################
                ##############################################################
                ##############################################################
                ################ Inserting Todays n_calls into Data ##########

                self.n_calls_deptsplit[programID] = ncalls_df[['NCalls', 'first_calldate']]

                print()
                print()
                print()

                print("NCalls Var Head: ", ncalls_df[['NCalls', 'first_calldate']].columns)

                print()
                print()
                print()
                print()

            elif write == False:
                temp_df = temp_df.groupby("BTN").first()

                temp_df.loc[:,'ncalls_' + programID] = self.n_calls_frame[self.n_calls_frame['deptsplit'] == programID][
                    'NCalls']  # .fillna(0)
                temp_df.loc[:,'lastcalldate_' + programID] = self.n_calls_frame[self.n_calls_frame['deptsplit'] == programID][
                    'lastcalldate'].fillna('NA')
                temp_df.rename(columns={'ncalls_' + programID: 'ncalls_' + programID}, inplace=True)
                self.n_calls_deptsplit[programID] = pd.DataFrame(
                    temp_df[['ncalls_' + programID, 'lastcalldate_' + programID]])
                temp_df.to_csv('lastcalldate.csv')
                print()
                print()
                print()

                print("NCalls Var With ProgramID Head: ", pd.DataFrame(temp_df['ncalls_' + programID]).columns)
                print()

                print()
                print()
                print()

            logging.debug("Successfully Computing N Calls For ProgramID: " + str(programID) + " ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Computing N Calls For ProgramID: " + str(programID) + " ")

    def run_n_calls_with_time_period(self, extended):
        """
        This function just creates thread and calls n_calls_with_time_period()
        """
        logging.debug("Running N Calls With Time Period Computation In Threading")

        try:
            threads = []
            t = Thread(target=self.n_calls_with_time_period, args=("NONE", True, extended,), daemon=True)
            t.start()
            t.join()

            logging.debug("Successfully Running N Calls With Time Period Computation In Threading ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Running N Calls With Time Period Computation In Threading ")

    def n_calls_with_time_period(self, programID, write, extended):
        """
        1) temp_df using frame dataframe
        2) to get calls of each btn in a single day we used dataframe and group it using BTN and count number of callDate on that btns (callDate would be =fetch date  that's why call count of single day)
        3) renamed temp_df column(callDate to Ncalls) and added callDate column and made it equal to fetchdate
        4) dump this dataframe into db table (btnh_daywise_n_calls_table)
        5) creates primary keys and indexes on the table if data is inserted for the first time  (as per my understanding as I don't have the file table_Creation_flags).
        6) after checking extended variable value it prepares the query accordingly (query is basically it sums the Ncalls for according to the variables required by right joining btnh.daywise_n_calls_table with  btnh.current_btns)
        7) execute the above prepared query and stores the data into dataframe
        these upper steps are done for programid=NONE 
        and if your function is getting called again for different dept then First we will group temp_df by btn and then we will merge it with dataframe that was prepared by query. and after that we will append program_id with each column

        """

        logging.debug("Computing N Calls With Time Period For ProgramID: " + str(programID))

        try:
            ############################# 2 july 1 = 1 july - 1 = 30 june
            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            db_name = self.final_schema + ".btnh_daywise_n_calls_table "
            temp_df = self.frame[['calldate', self.department_split]]
            if write == True:
                
                n_calls_time_creation_conn = self.get_engine_connection(self.final_db)

                

                ##############################################################
                ################ Inserting Todays n_calls into Data ##########

                temp_df = (temp_df.groupby(["BTN"])[
                               'calldate'].count()).to_frame()  # .add( ncalls_df['NCalls'] , fill_value  = 0)
                temp_df.reset_index(level=0, inplace=True)
                temp_df.set_index("BTN", inplace=True)

                # temp_df = temp_df.groupby("BTN").first()

                temp_df.rename(columns={"calldate": "NCalls"}, inplace=True)
                temp_df.loc[:,'calldate'] = str(self.fetching_date.split(" ")[0])
                (db, cursor) = self.get_psycopg_db_cursor(self.final_db)
                if os.path.isfile('table_creation_flags.csv') == False or get_lookup_table_checks() == 1:
                    
                    pk_query="CREATE TABLE "+self.final_schema+".btnh_daywise_n_calls_table(\"BTN\" VARCHAR(65),\"NCalls\" INT, calldate date) DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calldate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """
                    GRANT ALL PRIVILEGES ON """ + self.final_schema+".btnh_daywise_n_calls_table TO " + self.role + "; "
                    print(pk_query)
                    cursor.execute(pk_query)
                    db.commit()
                    pk_query = " ALTER TABLE "  + self.final_schema + ".btnh_daywise_n_calls_table ALTER COLUMN \"BTN\" set NOT NULL, ADD PRIMARY KEY (\"BTN\",\"calldate\")" 
                    
                    print(pk_query)
                    cursor.execute(pk_query)
                    db.commit()
                    print("DONE WITH PK")

                csv_io = io.StringIO()
                temp_df.to_csv(csv_io, sep='\t', header=False, index=True)
                csv_io.seek(0)
            
                cursor.copy_expert("copy "+self.final_schema + ".btnh_daywise_n_calls_table from stdin with csv delimiter '\t'",csv_io)
                db.commit()
                ############ Getting Data From The Table #####################
                ################## For the Time being ########################
                if extended.lower() == "y":

                    ################ ASKED should be calldate = ncalls_24hours giving 0 but 48 giving some value #################
                    ########################################
                    query = """select b.\"BTN\"  AS \"BTN\",
                            COALESCE(sum(case when a.calldate >=          """ + passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                            COALESCE(sum(case when a.calldate >= (""" + passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date - interval '60 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_60days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '90 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_90days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '120 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_120days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '180 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_180days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """ :: date- interval '360 days' )  + interval '1 days') then a.\"NCalls\" end),0) ncalls_1year 
                            from """ + db_name + """ a
                            right join   """ + self.final_schema + """.btnh_current_btns b 
                            on a.\"BTN\" = b.\"BTN\"
                            group by b.\"BTN\" ;"""
                            
                else:
                    query = """select b.\"BTN\"  AS \"BTN\",
                            COALESCE(sum(case when a.calldate >=          """ + passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                            COALESCE(sum(case when a.calldate >= (""" + passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                            COALESCE(sum(case when a.calldate >=  ( (""" + passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month
                             from """ + db_name + """ a
                            right join   """ + self.final_schema + """.btnh_current_btns b 
                            on a.\"BTN\" = b.\"BTN\"
                            group by b.\"BTN\" ;"""

                try:
                    print("\nQUERY :", query)
                    print()
                    A_ncalls_df = (
                        pd.read_sql(
                            sql=query,
                            con=self.db,
                            chunksize=None,
                            index_col="BTN")
                    )

                    if extended.lower() == "y":
                        ncalls_df = A_ncalls_df.groupby("BTN").agg({

                            "ncalls_24hours": sum,
                            "ncalls_48hours": sum,
                            "ncalls_1week": sum,
                            "ncalls_1month": sum,
                            "ncalls_60days": sum,
                            "ncalls_90days": sum,
                            "ncalls_120days": sum,
                            "ncalls_180days": sum,
                            "ncalls_1year": sum
                        })

                    else:
                        ncalls_df = A_ncalls_df.groupby("BTN").agg({
                            "ncalls_24hours": sum,
                            "ncalls_48hours": sum,
                            "ncalls_1week": sum,
                            "ncalls_1month": sum,
                        })

                    self.n_calls_with_time_input = A_ncalls_df

                    n_calls_time_creation_conn.close()
                    cursor.close()
                    db.close()
                    
                except Exception as e:
                    self.all_good = False
                    logging.exception(
                        "Exception Occur :" + str(e) + " In Computing N Calls With Time Period For ProgramID: " + str(
                            programID) + " ")

                print()
                print()
                print()

                print("NCalls Var With Period Head: ", ncalls_df.columns)
                print()

                print()
                print()
                print()

                ##############################################################
                ##############################################################

                self.n_calls_For_All_deptsplit[programID] = ncalls_df


            elif write == False:

                temp_df = temp_df.groupby("BTN").first()

                ####### From Here ####                                                          
                df = pd.merge(self.n_calls_with_time_input[self.n_calls_with_time_input['deptsplit'] == programID],
                              temp_df[[]], on="BTN", how='right').fillna(0)
                del df['deptsplit']
                df.columns = [i + "_" + programID for i in df.columns]
                self.n_calls_For_All_deptsplit[programID] = df

                print()
                print()
                print()

                print("NCalls Var With Peroid With ProgramID Head: ", df.columns)
                print()

                print()
                print()
                print()

            logging.debug("Successfully Computing N Calls With Time Period For ProgramID: " + str(programID) + " ")

        except Exception as e:
            self.all_good = False
            logging.exception(
                "Exception Occur :" + str(e) + " In Computing N Calls With Time Period For ProgramID: " + str(
                    programID) + " ")

    ############# Prepare Since Variables ##############

    def set_split_hour(self):
        """
        Set splitting hour for hour based lag
        """
        logging.debug("Setting split hour")
        try:
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            database = cfg['mysql']['LagDays'].split(".")[0]
            split_hour_conn =  self.get_engine_connection(database)

            query = "   select * from "+cfg['mysql']['LagDays']+  " where cdate = DATE('"+self.fetching_date+"') ;"
            print("\nQUERY :",query)
            print()
            ############ Getting Data From The Table #####################
            split_hour_df  =  (
                    pd.read_sql(
                    sql=query,
                            con=split_hour_conn,
                            chunksize=None)
                        )
            self.split_hour = str(split_hour_df.date.values[0]).replace("T"," ")
            logging.debug("Successfully Done Setting split hour with split hour: "+str(self.split_hour))
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :"+str(e)+" Setting split hour ")
            
    def compute_ncalls_time_period_of_sme_variables(self, extended):
        """
        This function is called in sme_update to ncalls variables, this is done by joining btnh_future_n_calls_table and btnh_
        sme_btns and calculate variables in query and result is assigned to dataframe which is used in sme_update() to assign values
        """
        logging.debug("Creating Sme N Calls With Time Period  ")

        try:
            LookUp_creation_conn = self.get_engine_connection(self.final_db)

            format_str = '%Y-%m-%d'

            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            previous_passedDate = "'" + str((datetime.datetime.strptime(str(self.fetching_date.split(" ")[0]),
                                                                        format_str) + datetime.timedelta(
                days=int(-1))).date()) + "'"
            if extended.lower() == "y":

                query = """
                            select b.\"BTN\"  AS \"BTN\",
                            COALESCE(sum(case when a.calldate >=          """ + previous_passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                            COALESCE(sum(case when a.calldate >= (""" + previous_passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date - interval '60 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_60days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '90 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_90days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '120 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_120days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '180 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_180days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '360 days' )  + interval '1 days') then a.\"NCalls\" end),0) ncalls_1year 
                           
                """
            else:
                query = """
                select b.\"BTN\"  AS \"BTN\",
                            COALESCE(sum(case when a.calldate >=          """ + previous_passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                            COALESCE(sum(case when a.calldate >= (""" + previous_passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month
                """

            query += "from " + self.final_schema + """."btnh_future_n_calls_table" a  
            inner join """ + self.final_schema + """."btnh_sme_btns" b 
            on a.\"BTN\" = b.\"BTN\" 
            where 
            a.calldate <= (""" + passedDate + """::date - interval ' 1 days')
            group by b.\"BTN\" ;""".replace('\n', ' ')          
            print()
            print("\nQUERY :", query)
            print()

            self.sme_n_calls_time_period = (
                pd.read_sql(
                    sql=query,
                    con=LookUp_creation_conn,
                    chunksize=None
                    , index_col='BTN')

            )
            LookUp_creation_conn.close()

            logging.debug("Successfully Creating Sme N Calls With Time Period  ")

        except Exception as e:
            logging.exception("Exception Occur :" + str(e) + " In Sme N Calls With Time Period  ")
            self.all_good = False

    ####################################################

    ############# Prepare Since Variables ##############
    def compute_since_variables(self):
        """
        This function is called in sme_update to compute since variables, 
        this is done by joining btnh_future_n_calls_table and btnh_current_btns and calculate variables in query.
        """
        logging.debug("Creating Sme Since Variables  ")

        try:
            LookUp_creation_conn =self.get_engine_connection(self.final_db)
            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            query = """
            
                select b.\"BTN\" as \"BTN\", a.deptsplit as deptsplit,
                abs(max(a.calldate)::date - """ + passedDate + """::date)  as days_since_last_call ,
                floor(abs((max(a.calldate)::date - """ + passedDate + """::date)/7)) as weeks_since_last_call,
                abs(DATE_PART('year', AGE(max(a.calldate), """ + passedDate + """)))*12+abs(DATE_PART('months', AGE(max(a.calldate), """ + passedDate + """)))  as months_since_last_call,
                abs(min(a.calldate)::date - """ + passedDate + """::date) as days_since_first_call,
                floor(abs((min(a.calldate)::date - """ + passedDate + """::date)/7)) as weeks_since_first_call,
                abs(DATE_PART('year', AGE(min(a.calldate), """ + passedDate + """)))*12+abs(DATE_PART('months', AGE(min(a.calldate), """ + passedDate + """))) as months_since_first_call
                """

            query += """ from """ + self.final_schema + """.btnh_future_n_calls_table a   
            inner join
            """ + self.final_schema + """.btnh_current_btns b 
            on a.\"BTN\" = b.\"BTN\" 
            where 
            a.calldate <= (""" + passedDate + """::date - interval ' 1 days')
            group by b.\"BTN\" , a.deptsplit ;""".replace('\n', ' ')

            print()
            print("\nQUERY :", query)
            print()

            self.since_df = (
                pd.read_sql(
                    sql=query,
                    con=LookUp_creation_conn,
                    chunksize=None
                    , index_col='BTN')

            )

            LookUp_creation_conn.close()
            logging.debug("Creating Sme Since Variables  ")


        except Exception as e:
            logging.exception("Exception Occur :" + str(e) + " In Creating Sme Since Variables  ")
            self.all_good = False

        ##################################

    ####################################################
     
    ################# UPDATE SME #######################
    def sme_update(self, extended):
        """
        This function is used to update btnhistory table: 
        the first step is it creates btnh_sme_btns in database by joining lookuptable and btnh_current_btns table in database. 
        The dataframe created by joining the tables later it is used after calculating some variables for sme and then values of those variables are updated in dataframe.
        After, updating dataframe that is dumped into staging table named btnh_btn_history_stagging after that table creation flags are checked and action is performed according to the flag value.
        """
        logging.debug("Populating BTN History Sme Insertion")

        try:

            LookUp_creation_conn = self.get_engine_connection(self.final_db)
            (db, cursor) = self.get_psycopg_db_cursor(self.final_db)

            sme_first_creation = self.get_sme_table_checks()

            if sme_first_creation > 0:
                query = "select a.* from " + self.final_schema + "." + self.BTN_history_lookup_name + " a inner join  " + self.final_schema + ".btnh_current_btns b  on a.\"BTN\" = b.\"BTN\"  ;"
                prev_lookUp_df = (
                    pd.read_sql(
                        sql=query,
                        con=LookUp_creation_conn,
                        chunksize=None,
                        index_col="BTN")
                )

                ########### to df previous BTNs with indexs ############
                stmt="Drop table if exists "+self.final_schema+".btnh_sme_btns;"
                cursor.execute(stmt)
                db.commit()

                stmt="create table "+self.final_schema+".btnh_sme_btns(\"BTN\" VARCHAR(65)) DISTRIBUTED BY (\"BTN\");  GRANT ALL PRIVILEGES ON " + self.final_schema+".btnh_sme_btns TO " + self.role + "; "
                cursor.execute(stmt)
                db.commit()

                csv_io = io.StringIO()
                prev_lookUp_df[[]].to_csv(csv_io, sep='\t', header=False, index=True)
                csv_io.seek(0)

                cursor.copy_expert("copy "+self.final_schema + ".btnh_sme_btns from stdin with csv delimiter '\t'",csv_io)
                db.commit()

                
                ########################################################

                del prev_lookUp_df['first_call']

                del prev_lookUp_df['calcdate']
                prev_lookUp_df.loc[:,"calcdate"] = str(((self.fetching_date.split(" "))[0]))

                ######### launch since thread and NCalls time period thread ######
                ########### Todays - 1 day for NCalls time period ################
                x1 = Thread(target=self.compute_since_variables, daemon=True)
                x1.start()
                x2 = Thread(target=self.compute_ncalls_time_period_of_sme_variables, args=(extended,), daemon=True)
                x2.start()
                ##################################################################

                del prev_lookUp_df['days_since_last_call']
                del prev_lookUp_df['days_since_first_call']
                del prev_lookUp_df['weeks_since_first_call']
                del prev_lookUp_df['months_since_first_call']

                del prev_lookUp_df['weeks_since_last_call']
                del prev_lookUp_df['months_since_last_call']

                del prev_lookUp_df['ncalls_24hours']
                del prev_lookUp_df['ncalls_48hours']
                del prev_lookUp_df['ncalls_1week']
                del prev_lookUp_df['ncalls_1month']

                if extended.lower() == 'y':
                    del prev_lookUp_df['ncalls_60days']
                    del prev_lookUp_df['ncalls_90days']
                    del prev_lookUp_df['ncalls_120days']
                    del prev_lookUp_df['ncalls_180days']
                    del prev_lookUp_df['ncalls_1year']

                if len(self.queue_list) > 1:
                    for i in self.queue_list:
                        del prev_lookUp_df['days_since_last_call_' + i]
                        del prev_lookUp_df['days_since_first_call_' + i]
                        del prev_lookUp_df['weeks_since_last_call_' + i]
                        del prev_lookUp_df['months_since_last_call_' + i]
                        del prev_lookUp_df['weeks_since_first_call_' + i]
                        del prev_lookUp_df['months_since_first_call_' + i]

                #####################
                #  join since thread 
                x1.join()
                x2.join()
                #####################

                prev_lookUp_df.loc[:,'days_since_last_call'] = self.since_df['days_since_last_call'].groupby(
                    "BTN").min().fillna("NA")
                prev_lookUp_df.loc[:,'weeks_since_last_call'] = self.since_df['weeks_since_last_call'].groupby(
                    "BTN").min().fillna("NA")
                prev_lookUp_df.loc[:,'months_since_last_call'] = self.since_df['months_since_last_call'].groupby(
                    "BTN").min().fillna("NA")

                prev_lookUp_df.loc[:,'days_since_first_call'] = self.since_df['days_since_first_call'].groupby(
                    "BTN").max().fillna("NA")
                prev_lookUp_df.loc[:,'weeks_since_first_call'] = self.since_df['weeks_since_first_call'].groupby(
                    "BTN").max().fillna("NA")
                prev_lookUp_df.loc[:,'months_since_first_call'] = self.since_df['months_since_first_call'].groupby(
                    "BTN").max().fillna("NA")

                if len(self.queue_list) > 1:

                    for i in self.queue_list:
                        prev_lookUp_df.loc[:,'days_since_first_call_' + i] = self.since_df[self.since_df['deptsplit'] == i][
                            'days_since_first_call'].fillna("NA")
                        prev_lookUp_df.loc[:,'weeks_since_first_call_' + i] = self.since_df[self.since_df['deptsplit'] == i][
                            'weeks_since_first_call'].fillna("NA")
                        prev_lookUp_df.loc[:,'months_since_first_call_' + i] = self.since_df[self.since_df['deptsplit'] == i][
                            'months_since_first_call'].fillna("NA")

                        prev_lookUp_df.loc[:,'days_since_last_call_' + i] = self.since_df[self.since_df['deptsplit'] == i][
                            'days_since_last_call'].fillna("NA")
                        prev_lookUp_df.loc[:,'weeks_since_last_call_' + i] = self.since_df[self.since_df['deptsplit'] == i][
                            'weeks_since_last_call'].fillna("NA")
                        prev_lookUp_df.loc[:,'months_since_last_call_' + i] = self.since_df[self.since_df['deptsplit'] == i][
                            'months_since_last_call'].fillna("NA")

                logging.debug("Succesfully Computed Since Variables")

                ##################################
                ##################################

                print()
                print()
                print()

                ###############
                # join NCalls thread and prepare NCAlls time period #######
                ###############

                prev_lookUp_df.loc[:,'ncalls_24hours'] = self.sme_n_calls_time_period['ncalls_24hours']
                prev_lookUp_df.loc[:,'ncalls_48hours'] = self.sme_n_calls_time_period['ncalls_48hours']
                prev_lookUp_df.loc[:,'ncalls_1week'] = self.sme_n_calls_time_period['ncalls_1week']
                prev_lookUp_df.loc[:,'ncalls_1month'] = self.sme_n_calls_time_period['ncalls_1month']
                if extended.lower() == 'y':
                    prev_lookUp_df.loc[:,'ncalls_60days'] = self.sme_n_calls_time_period['ncalls_60days']
                    prev_lookUp_df.loc[:,'ncalls_90days'] = self.sme_n_calls_time_period['ncalls_90days']
                    prev_lookUp_df.loc[:,'ncalls_120days'] = self.sme_n_calls_time_period['ncalls_120days']
                    prev_lookUp_df.loc[:,'ncalls_180days'] = self.sme_n_calls_time_period['ncalls_180days']
                    prev_lookUp_df.loc[:,'ncalls_1year'] = self.sme_n_calls_time_period['ncalls_1year']

                print("prev_lookUp_df: ", prev_lookUp_df.columns)

                print()
                print("prev_lookUp_df INDEX: ", prev_lookUp_df.index.name)
                print()
                print()
                print()

                column_seq=self.get_standard_columns_sequence_for_creation(extended,True)
                prev_lookUp_df=prev_lookUp_df[column_seq]
                prev_lookUp_df = prev_lookUp_df.fillna("NA")
                #prev_lookUp_df.to_csv('btn_history_staging.csv')
                stmt="Drop table if exists "+self.final_schema+".btnh_btn_history_stagging;"
                cursor.execute(stmt)
                db.commit()
                data_typee=self.get_standard_columns_datatype_for_creation(extended,sme=True,stagging=True)
#                data_typee=" \"BTN\" VARCHAR(65) ,recent_e2e_sale_wireline_new VARCHAR(15) ,recent_e2e_sale_wireline_upgrade VARCHAR(15) ,recent_e2e_sale_wireless_new VARCHAR(15) ,recent_e2e_sale_wireless_upgrade VARCHAR(15) ,lastcall_e2e_sale_wireline_new VARCHAR(255) ,lastcall_e2e_sale_wireline_upgrade VARCHAR(255) ,lastcall_e2e_sale_wireless_new VARCHAR(255) ,lastcall_e2e_sale_wireless_upgrade VARCHAR(255) ,lastdeptsplit VARCHAR(20) ,\"NCalls\" VARCHAR(15) ,first_calldate date ,ncalls_119 VARCHAR(15) ,lastcalldate_119 VARCHAR(15) ,ncalls_187 VARCHAR(15) ,lastcalldate_187 VARCHAR(15) ,handletime_3_119 VARCHAR(15) ,handletime_4_119 VARCHAR(15) ,handletime_5_119 VARCHAR(15) ,handletime_3_187 VARCHAR(15) ,handletime_4_187 VARCHAR(15) ,handletime_5_187 VARCHAR(15) ,handletime_3_lastcall VARCHAR(15) ,handletime_4_lastcall VARCHAR(15) ,handletime_5_lastcall VARCHAR(15) ,lastcalldate date ,first_call_187 VARCHAR(1) ,first_call_119 VARCHAR(1) ,calcdate date ,days_since_last_call VARCHAR(15) ,weeks_since_last_call VARCHAR(15) ,months_since_last_call VARCHAR(15) ,days_since_first_call VARCHAR(15) ,weeks_since_first_call VARCHAR(15) ,months_since_first_call VARCHAR(15) ,days_since_first_call_187 VARCHAR(15) ,weeks_since_first_call_187 VARCHAR(15) ,months_since_first_call_187 VARCHAR(15) ,days_since_last_call_187 VARCHAR(15) ,weeks_since_last_call_187 VARCHAR(15) ,months_since_last_call_187 VARCHAR(15) ,days_since_first_call_119 VARCHAR(15) ,weeks_since_first_call_119 VARCHAR(15) ,months_since_first_call_119 VARCHAR(15) ,days_since_last_call_119 VARCHAR(15) ,weeks_since_last_call_119 VARCHAR(15) ,months_since_last_call_119 VARCHAR(15) ,ncalls_24hours VARCHAR(15) ,ncalls_48hours VARCHAR(15) ,ncalls_1week VARCHAR(15) ,ncalls_1month VARCHAR(15) " 
                stmt="create table "+self.final_schema+".btnh_btn_history_stagging("+data_typee+") DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calcdate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') ) ;" + """ 
                 GRANT ALL PRIVILEGES ON """ + self.final_schema+".btnh_btn_history_stagging TO " + self.role + "; "
                cursor.execute(stmt)
                db.commit()

                csv_io = io.StringIO()
                prev_lookUp_df.to_csv(csv_io, sep='\t', header=False, index=True)
                csv_io.seek(0)

                cursor.copy_expert("copy "+self.final_schema + ".btnh_btn_history_stagging from stdin with csv delimiter '\t'",csv_io)
                db.commit()
                
                if len(self.queue_list) > 1:
                    for i in self.queue_list:
                        stmt="update "+self.final_schema+".btnh_btn_history_stagging set lastcalldate_"+i+"=null where lastcalldate_"+i+"='NA';"
                        cursor.execute(stmt)
                        db.commit()
           
                col_names = self.get_standard_columns_sequence(extended, sme=True)
                col_namess=self.get_standard_columns_sequence_for_stagging(extended,True)
            if sme_first_creation == 0:
                self.update_sme_table_checks(1)

            elif sme_first_creation == 1:
                
                logging.debug('Data typee '+data_typee)
                data_typee=self.get_standard_columns_datatype_for_creation(extended,sme=True,stagging=False)
                stmt="create table " + self.final_schema + "." + self.BTN_history_sme_name + " ("+data_typee+") DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calcdate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """
                """ + "insert into " + self.final_schema + "." + self.BTN_history_sme_name + "  select "+col_namess+" from "  + self.final_schema + ".btnh_btn_history_stagging ;" + """ 
                GRANT ALL PRIVILEGES ON """ + self.final_schema+ "." + self.BTN_history_sme_name + " TO " + self.role + "; "
                   
                #stmt = "create table " + self.final_schema + "." + self.BTN_history_sme_name + " AS select " + col_names + " from " + self.final_schema + ".btnh_btn_history_stagging DISTRIBUTED BY (\"BTN\")"

                cursor.execute(stmt)
                db.commit()

                print("2nd THUS DONE WITH SCHEMA CREATION")

                try:
                    pk_query = "ALTER TABLE " + self.final_schema + "." + self.BTN_history_sme_name + " ALTER COLUMN \"BTN\" set NOT NULL , ALTER COLUMN calcdate set NOT NULL , ADD PRIMARY KEY (\"BTN\",calcdate);"
                    cursor.execute(pk_query)
                    db.commit()

                    print("2nd Day Thus DONE WITH PKs BTN History")

                except Exception as identifier:
                    logging.exception("Exception Occur :" + str(identifier) + " In Creating keys on btnhistory_sme table  ")
                    self.all_good = False

                print("HISTORY HAS BEEN REPLACED")

                self.update_sme_table_checks(2)

            elif sme_first_creation == 2:
                
                stmt = "delete from " + self.final_schema + "." + self.BTN_history_sme_name + " as A using " + self.final_schema + ".btnh_btn_history_stagging as  B where A.\"BTN\" = B.\"BTN\" AND A.calcdate=B.calcdate;"
                print("REPLACE INTO QUERY: ", stmt)
                cursor.execute(stmt)
                db.commit()
                
                stmt = "insert into " + self.final_schema + "." + self.BTN_history_sme_name + "(  " + col_names + " ) select   " + col_namess + "  from " + self.final_schema + ".btnh_btn_history_stagging; "
                print("REPLACE INTO QUERY: ", stmt)
                cursor.execute(stmt)
                db.commit()
                
                print("HISTORY HAS BEEN REPLACED")

                self.update_sme_table_checks(2)

            LookUp_creation_conn.close()
            cursor.close()
            db.close()
            logging.debug("Successfully Populating BTN History Sme Insertion")

        except Exception as e:
            print("ERROR IN BTN HISTORY PRCOESS: ", str(e))
            logging.exception("Exception Occur :" + str(e) + " In Populating BTN History Sme Insertion ")

            self.all_good = False

    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##########################                                                 #######################
    ##########################                                                 #######################
    ##########################                                                 #######################
    ##########################            SME UPDATE WITH LAG DATE             #######################
    ##########################                                                 #######################
    ##########################                                                 #######################
    ##########################                                                 #######################
    ##########################                                                 #######################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################

    ############# Prepare Since Variables ##############
    def compute_ncalls_time_period_of_sme_variables_with_lag_days(self, extended):
        """
        This function is similar to compute_ncalls_time_period_of_sme_variables(), 
        the change is just in query where clause that lagdays value is considered and subtracted from the current fetchdate
        """
        logging.debug("Creating Sme N Calls With Time Period  ")

        try:

            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            
            LagDays = cfg['mysql']['LagDays']
            
            LookUp_creation_conn = self.get_engine_connection(self.final_db)

            format_str = '%Y-%m-%d'

            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            previous_passedDate = "'" + str((datetime.datetime.strptime(str(self.fetching_date.split(" ")[0]),
                                                                        format_str) + datetime.timedelta(
                days=(int(LagDays) + 1) * (-1))).date()) + "'"
            if extended.lower() == "y":

                
                query = """
                            select b.\"BTN\" AS \"BTN\",
                            COALESCE(sum(case when a.calldate >=          """ + previous_passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                            COALESCE(sum(case when a.calldate >= (""" + previous_passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date - interval '60 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_60days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '90 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_90days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '120 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_120days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '180 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_180days,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """ :: date- interval '360 days' )  + interval '1 days') then a.\"NCalls\" end),0) ncalls_1year 
                           
                """
            else:
                query = """
                select b.\"BTN\"  AS \"BTN\",
                            COALESCE(sum(case when a.calldate >=          """ + previous_passedDate + """ :: date then a.\"NCalls\" end),0) ncalls_24hours,
                            COALESCE(sum(case when a.calldate >= (""" + previous_passedDate + """ :: date - interval '1 days') then a.\"NCalls\" end),0) ncalls_48hours,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '1 weeks')  + interval '1 days')  then a.\"NCalls\" end),0) ncalls_1week,
                            COALESCE(sum(case when a.calldate >=  ( (""" + previous_passedDate + """:: date - interval '30 days' ) + interval '1 days') then a.\"NCalls\" end),0) ncalls_1month
                              
                """

            query += """ from """ + self.final_schema + """.btnh_future_n_calls_table a   
            inner join
            """ + self.final_schema + """.btnh_sme_btns b 
            on a.\"BTN\" = b.\"BTN\" 
            where 
            a.calldate <= (""" + passedDate + """::date - interval '""" + str(int(LagDays) + 1) + """ days')
            group by b.\"BTN\"  ;""".replace('\n', ' ')

            print()
            print("\nQUERY :", query)
            print()

            self.sme_n_calls_time_period = (
                pd.read_sql(
                    sql=query,
                    con=LookUp_creation_conn,
                    chunksize=None
                    , index_col='BTN')

            )
            LookUp_creation_conn.close()

            logging.debug("Successfully Creating Sme N Calls With Time Period  ")

        except Exception as e:
            logging.exception("Exception Occur :" + str(e) + " In Sme N Calls With Time Period  ")
            self.all_good = False

    ####################################################

    ############# Prepare Since Variables ##############
    def compute_since_variables_with_lag_days(self):
        """
        This function is similar to compute_since_variable, 
        the change is just in query where clause that lagdays value is considered and subtracted from the current fetchdate
        """
        logging.debug("Creating Sme Since Variables  ")

        try:
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            
            LagDays = cfg['mysql']['LagDays']
            
            LookUp_creation_conn = self.get_engine_connection(self.final_db)
            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            query = """

                select b.\"BTN\" as \"BTN\", a.deptsplit as deptsplit,
                abs(max(a.calldate)::date - """ + passedDate + """::date)  as days_since_last_call ,
                floor(abs((max(a.calldate)::date - """ + passedDate + """::date)/7)) as weeks_since_last_call,
                abs(DATE_PART('year', AGE(max(a.calldate), """ + passedDate + """)))*12+abs(DATE_PART('months', AGE(max(a.calldate), """ + passedDate + """)))  as months_since_last_call,
                abs(min(a.calldate)::date - """ + passedDate + """::date) as days_since_first_call,
                floor(abs((min(a.calldate)::date - """ + passedDate + """::date)/7)) as weeks_since_first_call,
                abs(DATE_PART('year', AGE(min(a.calldate), """ + passedDate + """)))*12+abs(DATE_PART('months', AGE(min(a.calldate), """ + passedDate + """))) as months_since_first_call
                """ 

            query += """ from """ + self.final_schema + """.btnh_future_n_calls_table a   
            inner join
            """ + self.final_schema + """.btnh_current_btns b 
            on a.\"BTN\" = b.\"BTN\" 
            where 
            a.calldate <= (""" + passedDate + """::date - interval '""" + str(int(LagDays) + 1) + """ days')
            group by b.\"BTN\" , a.deptsplit ;""".replace('\n', ' ')

            print()
            print("\nQUERY :", query)
            print()

            self.since_df = (
                pd.read_sql(
                    sql=query,
                    con=LookUp_creation_conn,
                    chunksize=None
                    , index_col='BTN')

            )

            LookUp_creation_conn.close()
            logging.debug("Creating Sme Since Variables  ")


        except Exception as e:
            logging.exception("Exception Occur :" + str(e) + " In Creating Sme Since Variables  ")
            self.all_good = False

    ####################################################

    ################# UPDATE SME #######################
    def sme_update_with_lag_days(self, extended):
        """
        This function is similar to sme_update() function, if lag day utility is on then this function is called rather than sme_update(), 
        new Date is calulcated through fetching date considering the lag days and then this new date is used for further extraction of data. 
        First dataframe is prepared by joining btnh_historical_lookup and btnh_current_btns table. 
        After that rank is given by grouping dataframe through btn and giving ranks to lastcalldate. 
        After that latest data is fetched by select rank==1 rows in dataframe and then this final dataframe is dumped into database in btnh_sme_btns.
        Rest is same as sme_update()
        """
        logging.debug("Populating BTN History Sme Insertion")

        try:
            with open('credentials.json', 'r') as f:
                cfg = json.load(f)
            LagDays_Units = (cfg['mysql']['LagDays_Units']).lower()
            if LagDays_Units  == 'days' or LagDays_Units == 'day':            
                LagDays = cfg['mysql']['LagDays']

            if LagDays_Units  == 'hours' or LagDays_Units == 'hour':            
                LagDays = 1
          
            LookUp_creation_conn = self.get_engine_connection(self.final_db)
            (db, cursor) = self.get_psycopg_db_cursor(self.final_db)

            format_str = '%Y-%m-%d'

            sme_first_creation  = self.get_sme_table_checks()
            
            previous_passedDate  = "'"+ str( (datetime.datetime.strptime(str(self.fetching_date.split(" ")[0]), format_str)  + datetime.timedelta(days= ( int(LagDays) + 1 ) * (-1) )).date() )+"'"
            

            col_names = self.get_standard_columns_sequence(extended)
            col_names=col_names.replace('\"BTN\"','a.\"BTN\"')

            if sme_first_creation > 0:

                if LagDays_Units  == 'hours' or LagDays_Units == 'hour':            
                    query  = "select "+col_names+" from "+self.final_schema+".btnh_historical_lookup a inner join  "+self.final_schema+".btnh_current_btns b  on a.\"BTN\" = b.\"BTN\"  where b."+self.date_col+" <= '"+self.split_hour+"' :: datetime and calcdate <= "+previous_passedDate+";"
            
                else:
                    query  = "select "+col_names+" from "+self.final_schema+".btnh_historical_lookup a inner join  "+self.final_schema+".btnh_current_btns b  on a.\"BTN\" = b.\"BTN\"  where calcdate <= "+previous_passedDate+";"
                prev_lookUp_df  =  (
                        pd.read_sql(
                                sql=query,
                                con=LookUp_creation_conn,
                                chunksize=None,
                                index_col = "BTN")
                            )

                
                print("SME QUERY: ",query)
                logging.debug("Populating BTN History Sme Insertion Query: "+query)

                if len(prev_lookUp_df) > 0:

                    prev_lookUp_df.loc[:,'lastcalldate'] = prev_lookUp_df['lastcalldate'].apply(pd.to_datetime)

                    ############ getting lastset Data ####################
                    prev_lookUp_df.loc[:,'rank'] = prev_lookUp_df.groupby('BTN')['lastcalldate'].rank(method='first',
                                                                                                ascending=False)
                    prev_lookUp_df = prev_lookUp_df[prev_lookUp_df['rank'] == 1]
                    ######################################################  

                    ########### to df previous BTNs with indexs ############
                    stmt="Drop table if exists "+self.final_schema+".btnh_sme_btns;"
                    cursor.execute(stmt)
                    db.commit()
                    
                    stmt="create table "+self.final_schema+".btnh_sme_btns(\"BTN\" VARCHAR(65)) DISTRIBUTED BY (\"BTN\"); GRANT ALL PRIVILEGES ON " + self.final_schema+ ".btnh_sme_btns TO " + self.role + "; "
                    cursor.execute(stmt)
                    db.commit()

                    csv_io = io.StringIO()
                    prev_lookUp_df[[]].to_csv(csv_io, sep='\t', header=False, index=True)
                    csv_io.seek(0)

                    cursor.copy_expert("copy "+self.final_schema + ".btnh_sme_btns from stdin with csv delimiter '\t'",csv_io)
                    db.commit()
                    
                    ########################################################

                    del prev_lookUp_df['first_call']

                    del prev_lookUp_df['calcdate']
                    prev_lookUp_df.loc[:,"calcdate"] = str(((self.fetching_date.split(" "))[0]))

                    ######### launch since thread and NCalls time period thread ######
                    ########### Todays - 1 day for NCalls time period ################
                    x1 = Thread(target=self.compute_since_variables_with_lag_days, daemon=True)
                    x1.start()
                    x2 = Thread(target=self.compute_ncalls_time_period_of_sme_variables_with_lag_days, args=(extended,),
                                daemon=True)
                    x2.start()
                    ##################################################################

                    del prev_lookUp_df['days_since_last_call']
                    del prev_lookUp_df['days_since_first_call']
                    del prev_lookUp_df['weeks_since_first_call']
                    del prev_lookUp_df['months_since_first_call']

                    del prev_lookUp_df['weeks_since_last_call']
                    del prev_lookUp_df['months_since_last_call']

                    del prev_lookUp_df['ncalls_24hours']
                    del prev_lookUp_df['ncalls_48hours']
                    del prev_lookUp_df['ncalls_1week']
                    del prev_lookUp_df['ncalls_1month']

                    if extended.lower() == 'y':
                        del prev_lookUp_df['ncalls_60days']
                        del prev_lookUp_df['ncalls_90days']
                        del prev_lookUp_df['ncalls_120days']
                        del prev_lookUp_df['ncalls_180days']
                        del prev_lookUp_df['ncalls_1year']

                    if len(self.queue_list) > 1:
                        for i in self.queue_list:
                            del prev_lookUp_df['days_since_last_call_' + i]
                            del prev_lookUp_df['days_since_first_call_' + i]
                            del prev_lookUp_df['weeks_since_last_call_' + i]
                            del prev_lookUp_df['months_since_last_call_' + i]
                            del prev_lookUp_df['weeks_since_first_call_' + i]
                            del prev_lookUp_df['months_since_first_call_' + i]

                    #####################
                    #  join since thread 
                    x1.join()


                    x2.join()
                    #####################

                    prev_lookUp_df.loc[:,'days_since_last_call'] = self.since_df['days_since_last_call'].groupby(
                        "BTN").min().fillna("NA")
                    prev_lookUp_df.loc[:,'weeks_since_last_call'] = self.since_df['weeks_since_last_call'].groupby(
                        "BTN").min().fillna("NA")
                    prev_lookUp_df.loc[:,'months_since_last_call'] = self.since_df['months_since_last_call'].groupby(
                        "BTN").min().fillna("NA")

                    prev_lookUp_df.loc[:,'days_since_first_call'] = self.since_df['days_since_first_call'].groupby(
                        "BTN").max().fillna("NA")
                    prev_lookUp_df.loc[:,'weeks_since_first_call'] = self.since_df['weeks_since_first_call'].groupby(
                        "BTN").max().fillna("NA")
                    prev_lookUp_df.loc[:,'months_since_first_call'] = self.since_df['months_since_first_call'].groupby(
                        "BTN").max().fillna("NA")

                    if len(self.queue_list) > 1:

                        for i in self.queue_list:
                            prev_lookUp_df.loc[:,'days_since_first_call_' + i] = \
                                self.since_df[self.since_df['deptsplit'] == i]['days_since_first_call'].fillna("NA")
                            prev_lookUp_df.loc[:,'weeks_since_first_call_' + i] = \
                                self.since_df[self.since_df['deptsplit'] == i]['weeks_since_first_call'].fillna("NA")
                            prev_lookUp_df.loc[:,'months_since_first_call_' + i] = \
                                self.since_df[self.since_df['deptsplit'] == i]['months_since_first_call'].fillna("NA")

                            prev_lookUp_df.loc[:,'days_since_last_call_' + i] = \
                                self.since_df[self.since_df['deptsplit'] == i]['days_since_last_call'].fillna("NA")
                            prev_lookUp_df.loc[:,'weeks_since_last_call_' + i] = \
                                self.since_df[self.since_df['deptsplit'] == i]['weeks_since_last_call'].fillna("NA")
                            prev_lookUp_df.loc[:,'months_since_last_call_' + i] = \
                                self.since_df[self.since_df['deptsplit'] == i]['months_since_last_call'].fillna("NA")

                    logging.debug("Succesfully Computed Since Variables")

                    ##################################
                    ##################################

                    print()
                    print()
                    print()

                    ###############
                    # join NCalls thread and prepare NCAlls time period #######
                    ###############

                    prev_lookUp_df.loc[:,'ncalls_24hours'] = self.sme_n_calls_time_period['ncalls_24hours']
                    prev_lookUp_df.loc[:,'ncalls_48hours'] = self.sme_n_calls_time_period['ncalls_48hours']
                    prev_lookUp_df.loc[:,'ncalls_1week'] = self.sme_n_calls_time_period['ncalls_1week']
                    prev_lookUp_df.loc[:,'ncalls_1month'] = self.sme_n_calls_time_period['ncalls_1month']
                    if extended.lower() == 'y':
                        prev_lookUp_df.loc[:,'ncalls_60days'] = self.sme_n_calls_time_period['ncalls_60days']
                        prev_lookUp_df.loc[:,'ncalls_90days'] = self.sme_n_calls_time_period['ncalls_90days']
                        prev_lookUp_df.loc[:,'ncalls_120days'] = self.sme_n_calls_time_period['ncalls_120days']
                        prev_lookUp_df.loc[:,'ncalls_180days'] = self.sme_n_calls_time_period['ncalls_180days']
                        prev_lookUp_df.loc[:,'ncalls_1year'] = self.sme_n_calls_time_period['ncalls_1year']

                    print("prev_lookUp_df: ", prev_lookUp_df.columns)

                    print()
                    print("prev_lookUp_df INDEX: ", prev_lookUp_df.index.name)
                    print()
                    print()
                    print()
                    column_seq=self.get_standard_columns_sequence_for_creation(extended,True)
                    prev_lookUp_df=prev_lookUp_df[column_seq]
                    prev_lookUp_df = prev_lookUp_df.fillna("NA")
                    #prev_lookUp_df.to_csv('btn_history_staging.csv')
                    stmt="Drop table if exists "+self.final_schema+".btnh_btn_history_stagging;"
                    cursor.execute(stmt)
                    db.commit()
                    data_typee=self.get_standard_columns_datatype_for_creation(extended,sme=True,stagging=True)
                    stmt="create table "+self.final_schema+".btnh_btn_history_stagging("+data_typee+") DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calcdate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """ 
                    GRANT ALL PRIVILEGES ON """ + self.final_schema+ ".btnh_btn_history_stagging TO " + self.role + "; "
                    cursor.execute(stmt)
                    db.commit()

                    csv_io = io.StringIO()
                    prev_lookUp_df.to_csv(csv_io, sep='\t', header=False, index=True)
                    csv_io.seek(0)
                    
                    cursor.copy_expert("copy "+self.final_schema + ".btnh_btn_history_stagging from stdin with csv delimiter '\t'",csv_io)

                    db.commit()
                    
                    if len(self.queue_list) > 1:
                        for i in self.queue_list:
                            stmt="update "+self.final_schema+".btnh_btn_history_stagging set lastcalldate_"+i+"=null where lastcalldate_"+i+"='NA';"
                            cursor.execute(stmt)
                            db.commit()

                    col_names = self.get_standard_columns_sequence(extended, sme=True)
                    col_namess=self.get_standard_columns_sequence_for_stagging(extended,True)

                    if sme_first_creation == 1:
                        
                        data_typee=self.get_standard_columns_datatype_for_creation(extended,sme=True,stagging=False)
                        
                        stmt="create table " + self.final_schema + "." + self.BTN_history_sme_name + " ("+data_typee+") DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calcdate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """
                        """ + "insert into " + self.final_schema + "." + self.BTN_history_sme_name + "  select "+col_namess+" from "  + self.final_schema + ".btnh_btn_history_stagging ;" + """ 
                        GRANT ALL PRIVILEGES ON """ + self.final_schema + "." + self.BTN_history_sme_name + " TO " + self.role + "; "
                        
                        cursor.execute(stmt)
                        db.commit()

                        print("2nd THUS DONE WITH SCHEMA CREATION")

                        try:
                            pk_query = "ALTER TABLE " + self.final_schema + "." + self.BTN_history_sme_name + " ALTER COLUMN \"BTN\" set NOT NULL , ALTER COLUMN calcdate set NOT NULL , ADD PRIMARY KEY (\"BTN\",calcdate);"

                            cursor.execute(pk_query)
                            db.commit()
                                    
                            print("2nd Day Thus DONE WITH PKs BTN History")

                        except Exception as identifier:
                            logging.exception("Exception Occur :" + str(identifier) + " In Creating keys on btnhistory_sme table  ")
                            self.all_good = False

                        print("HISTORY HAS BEEN REPLACED")

                        self.update_sme_table_checks(2)

                    elif sme_first_creation == 2:
                        stmt = "delete from " + self.final_schema + "." + self.BTN_history_sme_name + " as A using " + self.final_schema + ".btnh_btn_history_stagging as  B where A.\"BTN\" = B.\"BTN\" AND A.calcdate=B.calcdate;"
                        print("REPLACE INTO QUERY: ", stmt)
                        cursor.execute(stmt)
                        db.commit()
                        
                        stmt = "insert into " + self.final_schema + "." + self.BTN_history_sme_name + "(  " + col_names + " ) select   " + col_namess + "  from " + self.final_schema + ".btnh_btn_history_stagging; "
                        print("REPLACE INTO QUERY: ", stmt)
                        cursor.execute(stmt)
                        db.commit()
                        
                        print("HISTORY HAS BEEN REPLACED")

                        self.update_sme_table_checks(2)

            elif sme_first_creation == 0:
                self.update_sme_table_checks(1)
                
            LookUp_creation_conn.close()
            cursor.close()
            db.close()
            logging.debug("Successfully Populating BTN History Sme Insertion")

        except Exception as e:
            print("ERROR IN BTN HISTORY PRCOESS: ", str(e))
            logging.exception("Exception Occur :" + str(e) + " In Populating BTN History Sme Insertion ")

            self.all_good = False

    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################
    ##################################################################################################

    ##################### LOOKUP #####################
    def populate_btn_lookup(self, LastDay, WritingVersion=False, version=0, extended='n'):
        """
        After computing and preparing all the data that has to be updated in main main btn lookup the dataframe named lookup is prepared using all the results 
        or dataframes/dictionaries prepared by function described above
        (recent_opt_var_df, outcomes_df,lastCall_var_df,n_calls_deptSplit,n_calls_For_All_deptSplit, AHT_For_All_NormalizationSplit).
        Data Manipulation is performed on the variables of that dataframe and some variables are added in that final dataframe and 
        after that dataframe is dumped into sql table (btnh_BTN_LookUp_Stagging). 
        If table is not created then first lookup table and historical lookup table is created and then the data is inserted into 
        that if tables are already created then directly data is replaced into the table. creation of table checks are done through table_ceation_flags file.
        """

        a = datetime.datetime.now().replace(microsecond=0)
        logging.debug("Populating BTN LookUp DataFrame")

        try:
            #### Geting BTN #####
            if len(self.final_source_data) <= 0:
                logging.debug("0 Zero Rows In Combined Data Source")
                return

            print(((self.fetching_date.split(" "))[0]))
            col_names = self.get_standard_columns_sequence(extended)
            
#            print(self.fetching_date)
            ddd = self.final_source_data[self.date_col]
            logging.debug(" Making Date Columns's ddd Series")
            self.final_source_data["calldate"] = ddd.dt.date
            logging.debug(" Add new calldate Columns From ddd")
            self.final_source_data = self.final_source_data.sort_values(by=str(self.date_col))
#            print(self.final_source_data['calldate'])
            logging.debug(" Sorting Data WRT CallTime")
            
            self.frame = self.final_source_data[
                self.final_source_data['calldate'] == self.convert(self.fetching_date.split(" ")[0])]
            
#            print(self.frame)
#            print(len(self.frame))
            self.update_previous_date_checks(self.fetching_date.split(" ")[0])
            logging.debug(" Getting Data Only For Fetching Date")
            if len(self.frame) <= 0:
                self.ncalls_Update(extended)
                logging.debug(" 0 Zero Rows In Frame Of That Day")
                
                return


            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            LagDays_Utility = (cfg['mysql']['LagDays_Utility']).lower()
            LagDays_Units = (cfg['mysql']['LagDays_Units']).lower()
            
            ########################## BTNS COUNTS ######################
            # self.frame=self.frame.reindex(columns=self.frame.columns) #
            #############################################################

            self.fill_current_btns()

            ################# N Calls For Time #####################################################
            x5 = Thread(target=self.run_n_calls_with_time_period, args=(extended,))
            x5.start()
            #########################################################################################
            ################## Previous N CALLS COMPUTATION #########################################
            if LastDay == True:
                x0 = Thread(target=self.prepare_previous_NCalls, args=(extended,), daemon=True)
            ###########################################################################################
            ############################# Module 01 LastCall Variables ################################
            ######################## DO RUN THIS IN THREAD ############################################
            x1 = Thread(target=self.compute_lastCalls_variables, daemon=True)
            x1.start()
            ###########################################################################################
            ############################# Module 02 optimization Variables ############################
            ######################## DO RUN THIS IN THREAD ############################################
            x2 = Thread(target=self.compute_optimization_variables, daemon=True)
            x2.start()
            ###########################################################################################
            ############################## Module 03 normalimzationSplit Variables ####################
            ######################### DO RUN THIS IN THREAD ###########################################
            x3 = Thread(target=self.compute_normalimzationSplit_variables, daemon=True)
            x3.start()
            #################################################################
            ################## N CALLS COMPUTATION ##########################
            x4 = Thread(target=self.run_n_calls)
            x4.start()
            #################################################################
            ###################### Update SME  ##############################
            if LagDays_Utility == 'true' and (LagDays_Units == 'hours' or LagDays_Units == 'hour'):
                self.set_split_hour()
                x6 = Thread(target = self.sme_update_with_lag_days, args=(extended,) , daemon=True )
                x6.start()
            
            elif LagDays_Utility == 'true' and (LagDays_Units == 'day' or LagDays_Units == 'days'):
                x6 = Thread(target = self.sme_update_with_lag_days, args=(extended,) , daemon=True )
                x6.start()
            
            else:
                x6 = Thread(target = self.sme_update, args=(extended,) , daemon=True )
                x6.start()
            
            #################################################################

            x5.join()
            if LastDay == True:
                x0.start()

            x1.join()
            x2.join()
            x3.join()
            x4.join()

            lookUp = pd.concat(
                [self.recent_opt_var_df, self.lastcall_var_df] + list(self.n_calls_deptsplit.values()) + list(
                    self.n_calls_For_All_deptsplit.values()) + list(self.AHT_For_All_NormalizationSplit.values()),
                axis=1)
            lookUp.loc[:,'calcdate'] = self.fetching_date.split(" ")[0]
            lookUp.loc[:,'lastcalldate'] = (self.frame['calldate'].groupby('BTN').first()).astype(str)
            lookUp.loc[:,'first_call'] = 0
            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    lookUp.loc[:,'first_call_' + i] = 0

            lookUp.rename(columns={'lastcall_lastdeptsplit': "lastdeptsplit"}, inplace=True)

            try:
                del lookUp['rank']
            except Exception as identifier:
                pass

            try:
                del lookUp['firstcall_' + self.date_col]
            except Exception as identifier:
                pass
            self.lookUp = lookUp           
            b = datetime.datetime.now().replace(microsecond=0)
            if WritingVersion == True:
                lookUp.to_csv("LookUp_V" + str(version) + ".csv")

           
            LookUp_creation_conn = self.get_engine_connection(self.final_db)

            ############## Since Var Computation ################
            self.lookUp.loc[:,'days_since_last_call'] = "NA"
            self.lookUp.loc[:,'days_since_first_call'] = "NA"

            self.lookUp.loc[:,'weeks_since_first_call'] = "NA"
            self.lookUp.loc[:,'months_since_first_call'] = "NA"

            self.lookUp.loc[:,'weeks_since_last_call'] = "NA"
            self.lookUp.loc[:,'months_since_last_call'] = "NA"

            if len(self.queue_list) > 1:

                for i in self.queue_list:
                    self.lookUp.loc[:,'days_since_last_call_' + i] = "NA"
                    self.lookUp.loc[:,'days_since_first_call_' + i] = "NA"

                    self.lookUp.loc[:,'weeks_since_first_call_' + i] = "NA"
                    self.lookUp.loc[:,'months_since_first_call_' + i] = "NA"

                    self.lookUp.loc[:,'weeks_since_last_call_' + i] = "NA"
                    self.lookUp.loc[:,'months_since_last_call_' + i] = "NA"

            print()
            print()
            print()

            # print("Since Var Head: ",since_df.columns)
            print()

            print()
            print()
            print()

            print()
            print()
            print()

            print("LookUp  Head: ", self.lookUp.columns)
            print()

            print("index", self.lookUp.index.name)
            print()
            self.lookUp.index.name = 'BTN'
            print()
            print("HEAD", self.lookUp.head(2))
            print()

            df = self.lookUp

            print()
            print()
            print()
            # df.rename(columns={"deptsplit":"lastdeptsplit"}, inplace= True)

            print("DF: ", df.columns)
            print()
            print("INDEX: ", df.index.name)
            print()
            print()
            print()

            ####### START ############

            try:
                del df['calldate']
            except Exception as e:
                pass

            if self.all_good == False:
                self.src_conn.close()
                self.creation_conn.close()
                LookUp_creation_conn.close()
                return "STOP"

            LookUp_creation_conn = self.get_engine_connection(self.final_db)
            (db, cursor) = self.get_psycopg_db_cursor(self.final_db)
            #df.to_csv("Lookupfin.csv")
            
            stmt="drop table if exists " + self.final_schema + ".btnh_BTN_LookUp_Stagging "
            cursor.execute(stmt)
            db.commit()
            print("Lookup Staging Table DROPPED .................................")
            
            
            col_names = self.get_standard_columns_sequence(extended)
            col_namess=self.get_standard_columns_sequence_for_stagging(extended,False)
            print(" of columns names", len(col_names), "\n its length: ", col_names)
#            df.fillna("NA")
            df = df.fillna("NA")
            column_seq=self.get_standard_columns_sequence_for_creation(extended,False)
            print(column_seq)
            df=df[column_seq]
            #df.to_csv("DF_COLUMN SEQUENCE CHECK.csv")
            data_typee=self.get_standard_columns_datatype_for_creation(extended,sme=False,stagging=True)
            stmt="create table " + self.final_schema + ".btnh_BTN_LookUp_Stagging ("+data_typee+") DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calcdate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """ 
            GRANT ALL PRIVILEGES ON """ + self.final_schema + ".btnh_BTN_LookUp_Stagging TO " + self.role + "; "
            print(stmt)
            cursor.execute(stmt)
            db.commit()
            
            csv_io = io.StringIO()
            df.to_csv(csv_io, sep='\t', header=False, index=True)
            csv_io.seek(0)
            
            cursor.copy_expert("copy "+self.final_schema + ".btnh_BTN_LookUp_Stagging from stdin with csv delimiter '\t'",csv_io)

            db.commit()
            if len(self.queue_list) > 1:
                for i in self.queue_list:
                    stmt="update "+self.final_schema+".btnh_BTN_LookUp_Stagging set lastcalldate_"+i+"=null where lastcalldate_"+i+"='NA';"
                    cursor.execute(stmt)
                    db.commit()

            print("Lookup Staging reached.................................")
            
            ####################################################
            ###### inner join of current BTN from LookUp #######
            
            x6.join()

            if LagDays_Utility == 'true' and (LagDays_Units == 'hours' or LagDays_Units == 'hour'):
                x6 = Thread(target = self.sme_update, args=(extended,) , daemon=True )
                x6.start()
                x6.join()

            if self.all_good == False:
                self.src_conn.close()
                self.creation_conn.close()
                LookUp_creation_conn.close()
                

                return "STOP"

                # ####################################################
                
            # ######## INSERT UPDATE SQL INTO ACTUAL LOOKUP #######
            try:
                lookup_first_creation = get_lookup_table_checks()

                if lookup_first_creation == 1:
                    data_typee=self.get_standard_columns_datatype_for_creation(extended,sme=False,stagging=False)
                    stmt="create table " + self.final_schema + "." + self.BTN_history_lookup_name + "("+data_typee+") DISTRIBUTED BY (\"BTN\") ;" + """
                    """ + "insert into " + self.final_schema + "." + self.BTN_history_lookup_name + " select "+col_namess+" from "  + self.final_schema + ".btnh_BTN_LookUp_Stagging;" + """ 
                    GRANT ALL PRIVILEGES ON """ + self.final_schema + "." + self.BTN_history_lookup_name + " TO " + self.role + "; "
                    print(stmt)
                    cursor.execute(stmt)
                    db.commit()

                    stmt="create table " + self.final_schema + ".btnh_historical_lookup ("+data_typee+") DISTRIBUTED BY (\"BTN\") PARTITION BY RANGE (calcdate)( START (date '2019-05-01') INCLUSIVE END (date '2023-01-01') EXCLUSIVE EVERY (INTERVAL '1 month') );" + """
                    """ + "insert into " + self.final_schema + ".btnh_historical_lookup  select "+col_namess+" from "  + self.final_schema + ".btnh_BTN_LookUp_Stagging;" + """ 
                    GRANT ALL PRIVILEGES ON """ + self.final_schema + ".btnh_historical_lookup TO " + self.role + "; "
                    
                    
                    print(stmt)
                    logging.debug(stmt)
                    cursor.execute(stmt)
                    db.commit()

                    try:
                        
                        pk_query = "ALTER TABLE " + self.final_schema + "." + self.BTN_history_lookup_name + " ALTER COLUMN \"BTN\" set NOT NULL , ADD PRIMARY KEY (\"BTN\");"
                        print(pk_query)
                        cursor.execute(pk_query)
                        db.commit()
                        print("DONE WITH PK")
                        
                        pk_query = "ALTER TABLE " + self.final_schema + ".btnh_historical_lookup  ALTER COLUMN \"BTN\" set NOT NULL ,ALTER COLUMN calcdate set NOT NULL , ADD PRIMARY KEY (\"BTN\",calcdate);"
                        print(pk_query)
                        cursor.execute(pk_query)
                        db.commit()
                        print("DONE WITH PK")

                    except Exception as identifier:
                        
                        print("ERROR IN BTN LOOKUP PRCOESS: ", str(identifier))
                        logging.exception("Exception Occur :" + str(identifier) + " In Populating BTN History LookUp Insertion ")

                        self.all_good = False

                    print("1st Day ... Thus DONE WITH 1st LookUp Insertion")
                    self.update_lookup_table_checks(2)

                elif lookup_first_creation == 2:

                    stmt = "delete from " + self.final_schema + "." + self.BTN_history_lookup_name + " as A using " + self.final_schema + ".btnh_BTN_LookUp_Stagging as  B where A.\"BTN\" = B.\"BTN\" ;"
                    print("REPLACE INTO QUERY: ", stmt)
                    cursor.execute(stmt)
                    db.commit()
                    
                    stmt = "insert into " + self.final_schema + "."+self.BTN_history_lookup_name + "(  " + col_names + " ) select   " + col_namess + "  from " + self.final_schema + ".btnh_BTN_LookUp_Stagging ; "
                    print("REPLACE INTO QUERY: ", stmt)
                    cursor.execute(stmt)
                    db.commit()
                

                    stmt = "delete from " + self.final_schema + ".btnh_historical_lookup as A using " + self.final_schema + ".btnh_BTN_LookUp_Stagging as  B where A.\"BTN\" = B.\"BTN\" and A.calcdate=B.calcdate;"
                    print("REPLACE INTO QUERY: ", stmt)
                    cursor.execute(stmt)
                    db.commit()
                    
                    stmt = "insert into " + self.final_schema + ".btnh_historical_lookup(  " + col_names + " ) select   " + col_namess + "  from " + self.final_schema + ".btnh_BTN_LookUp_Stagging ; "
                    print("REPLACE INTO QUERY: ", stmt)
                    cursor.execute(stmt)
                    db.commit()
                
                    print("LOOKUP HAS BEEN REPLACED")
                    # print("LOOKUP HAS BEEN REPLACED")

                    self.update_lookup_table_checks(2)

            except Exception as e:
                print("ERROR IN BTN LOOKUP PRCOESS: ", str(e))
                logging.exception("Exception Occur :" + str(e) + " In Populating BTN History LookUp Insertion ")

                self.all_good = False

            if self.all_good == False:
                self.src_conn.close()
                self.creation_conn.close()
                LookUp_creation_conn.close()
                cursor.close()
                db.close()

                return "STOP"

            if LastDay == True:
                x0.join()
                self.ncalls_Update(extended)

                if self.all_good == False:
                    self.src_conn.close()
                    self.creation_conn.close()
                    LookUp_creation_conn.close()
                    cursor.close()
                    db.close()
                    
                    return "STOP"

            ####################################
            self.src_conn.close()
            self.creation_conn.close()
            LookUp_creation_conn.close()
            cursor.close()
            db.close()
            logging.debug("Successfully Populating BTN LookUp DataFrame with Total Time: " + str(
                datetime.datetime.now().replace(microsecond=0) - a))

            return "DONT STOP"
        ### END ###
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Populating BTN LookUp DataFrame ")
            return "STOP"

        #############################################################

    def ncalls_Update(self, extended='n'):
        """
        This function is executed when it’s the last date of btn history generation, 
        because there maybe some btn who did not call on this last day so their values of ncalls with time periods needs to be updated, 
        so this is done by querying the database and updating lookup by joining it with btnh_previous_Ncalls and assigning ncall time period values in btnh_previous_ncalls to lookup table

        """
        logging.debug("Updating NCalls ")
        try:

            ############  2 july 1 = 1 july - 1 = 30 june
            passedDate = "'" + str(self.fetching_date.split(" ")[0]) + "'"
            db_name = "" + self.final_schema + ".btnh_daywise_n_calls_table"

            with open('credentials.json', 'r') as f:
                cfg = json.load(f)

            host = cfg['mysql']['host']
            port = cfg['mysql']['port']
            user = cfg['mysql']['user']
            password = cfg['mysql']['password']

            final_db = cfg['mysql']['finalDatabase'].split(".")[0].replace("", "")
            configtable = cfg['mysql']['ConfigTable']
            print(self.configtable)
            
            (db, cursor) = self.get_psycopg_db_cursor(self.final_db)
            
            q_list = ['NONE']

            for i in (q_list):
                
                if i == "NONE":
                    filter_ = ' where b.\"BTN\" is NULL '
                    col = ' '
                else:
                    filter_ = " where b.\"BTN\" is NULL and  a.deptsplit =  '" + i + "' "
                    col = '_' + i

                if get_lookup_table_checks() == 2 and self.get_sme_table_checks() == 2:

                    if extended.lower() == "y":
                        query = """
                        
                                with temp as ( SELECT b.*
                                
                                from """ + self.final_schema + """.btnh_btnhistory_lookup a
                                inner join """ + self.final_schema + """.btnh_previous_ncalls b
                                on a.\"BTN\" = b.\"BTN\"
                                )
                                
                                update """ + self.final_schema + """.btnh_btnhistory_lookup a
                                SET ncalls_24hours = b.ncalls_24hours,
                                ncalls_48hours = b.ncalls_48hours,
                                ncalls_1week = b.ncalls_1week,
                                ncalls_1month = b.ncalls_1month,
                                ncalls_60days = b.ncalls_60days,
                                ncalls_90days  = b.ncalls_90days ,
                                ncalls_120days  =  b.ncalls_120days,
                                ncalls_180days  = b.ncalls_180days,
                                ncalls_1year  = b.ncalls_1year
                                
                                from temp b
                                where a.\"BTN\" = b.\"BTN\";""".format(self.final_schema, self.BTN_history_lookup_name, i, col).replace("\n", ' ')



                    else:
                        query = """
                                with temp as ( SELECT b.*
                                
                                from """ + self.final_schema + """.btnh_btnhistory_lookup a
                                inner join """ + self.final_schema + """.btnh_previous_ncalls b
                                on a.\"BTN\" = b.\"BTN\"
                                )
                                
                                update """ + self.final_schema + """.btnh_btnhistory_lookup a
                                SET ncalls_24hours = b.ncalls_24hours,
                                ncalls_48hours = b.ncalls_48hours,
                                ncalls_1week = b.ncalls_1week,
                                ncalls_1month = b.ncalls_1month
                                
                                from temp b
                                where a.\"BTN\" = b.\"BTN\";""".format(self.final_schema, self.BTN_history_lookup_name, i, col).replace("\n", ' ')

                    print(query)
                    cursor.execute(query)
                    result = db.commit()
                logging.debug("Updating NCalls Done WIth Insertion in LookUp")
                
            cursor.close()
            db.close()
            logging.debug("Successfully Updating NCalls ")
        except Exception as e:
            self.all_good = False
            logging.exception("Exception Occur :" + str(e) + " In Updating NCalls ")