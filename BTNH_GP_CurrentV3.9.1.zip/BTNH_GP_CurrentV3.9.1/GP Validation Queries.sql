SET mycustom.startdate='2019-07-30';
/******************************************************************
-- Fetch All BTN's and their calling Dates from ACA
******************************************************************/
-- select A.btn as missingBTN,B.* from abc.missing_btn_in_lkp A left join abc.daywise_BTN_Testing B on A.btn=B.btn where calltime>='2019-03-23';
drop table if exists abc.daywise_BTN_Testing ;
create table abc.daywise_BTN_Testing as
select distinct BTN, date(calltime) as calltime, 0 as First_Occurance from abc.btnh_source where calltime >= '2019-07-24' ::timestamp and Calltime <= current_setting('mycustom.startdate') ::timestamp 

group by 1,2 ;




-- select * from abc.daywise_BTN_Testing ;

/*****************************
Mark the first Call
*******************************/
drop table if exists abc.daywise_BTN_Testing_first_call ;
create table abc.daywise_BTN_Testing_first_call as
Select btn,Min(calltime) as calltime
from abc.daywise_BTN_Testing
group by 1;

update abc.daywise_BTN_Testing A
set first_occurance=1
from abc.daywise_BTN_Testing_first_call B where A.BTN=B.BTN and A.calltime=B.calltime



/********************************
#Case1 Missing Valid BTNs in SME table
**********************************/
Select A.*, B."BTN" as BTN_H,B.Calcdate
from abc.daywise_BTN_Testing A
left join abc.btnh_btn_history
as B on A.BTN=B."BTN" and A.calltime=B.CalcDate
where B."BTN" is null and First_Occurance=0;
--Output:Ideally speaking, there should be no rows in the output of last query.

/********************************
#Case 2 - Check if All BTNs have correct First_CallDate in BTN History Lookup Table
#Case2 Wrongly Entered BTN in Lookup table
**********************************/
Select A.BTN, B."BTN", B.First_CallDate,A.calltime
from abc.daywise_BTN_Testing_first_call as A
left join abc.btnh_btnhistory_lookup as B on A.BTN=B."BTN"
where B.First_CallDate<>A.calltime ;
--#Output:Ideally speaking, there should be no rows in the output of last query.

/********************************
#Case 3 - Check if All BTN's exist in BTN History Lookup Table
**********************************/
Select A.BTN
from abc.daywise_BTN_Testing_first_call A
left join abc.btnh_btnhistory_lookup B on A.BTN=B."BTN"
where B."BTN" is null
group by 1;
#Output:Ideally speaking, there should be no rows in the output of last query.

/********************************
#Case 4 - Check if any BTN have multiple First_CallDate in BTN History SME Table
**********************************/
Select "BTN", Count(Distinct First_CallDate)
From abc.btnh_btn_history
Group by 1
Having Count(Distinct First_CallDate) > 1;
#Output:Ideally speaking, there should be no rows in the output of last query.






